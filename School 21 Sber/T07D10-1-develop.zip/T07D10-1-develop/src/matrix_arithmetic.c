#include <stdio.h>
#include <stdlib.h>

int input(int **matrix, int n, int m);
void output(int **matrix, int n, int m);
void sum(int **matrix_first, int n_first, int m_first, int **matrix_second, int **matrix_result);
int transpose(int **matrix, int n, int m);
void mult(int **matrix_first, int n_first, int m_first, int **matrix_second, int m_second,
          int **matrix_result);
int modeSum();
int inputNM(int *n, int *m);
int **allocate(int n1, int m1);
int modeMult();
void freeMemory(int **data, int n);
void trans(int **data, int n, int m, int **res);
int modeTrans();

int main() {
    double mode_d;
    if (scanf("%lf", &mode_d) != 1 || mode_d != (int)mode_d || (int)mode_d > 4 || (int)mode_d < 1) {
        printf("n/a");
        return 1;
    }
    int mode = (int)mode_d;

    switch (mode) {
        case 1:
            if (modeSum()) {
                printf("n/a");
            }
            break;
        case 2:
            if (modeMult()) {
                printf("n/a");
            }
            break;
        case 3:
            if (modeTrans()) {
                printf("n/a");
            }
            break;
        default:
            break;
    }
}

int modeTrans() {
    int n1 = 0, m1 = 0;
    if (inputNM(&n1, &m1)) {
        return 1;
    }
    int **data1 = allocate(n1, m1);
    if (input(data1, n1, m1)) {
        freeMemory(data1, n1);
        return 1;
    }

    int **res = allocate(m1, n1);
    trans(data1, n1, m1, res);
    output(res, m1, n1);

    freeMemory(data1, n1);
    freeMemory(res, n1);
    return 0;
}

void trans(int **data, int n, int m, int **res) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            res[j][i] = data[i][j];
        }
    }
}

int modeMult() {
    int n1 = 0, m1 = 0;
    if (inputNM(&n1, &m1)) {
        return 1;
    }
    int **data1 = allocate(n1, m1);
    if (input(data1, n1, m1)) {
        freeMemory(data1, n1);
        return 1;
    }

    int n2 = 0, m2 = 0;
    if (inputNM(&n2, &m2)) {
        freeMemory(data1, n1);
        return 1;
    }
    int **data2 = allocate(n2, m2);
    if (input(data2, n2, m2)) {
        freeMemory(data1, n1);
        freeMemory(data2, n2);
        return 1;
    }

    if (m1 != n2) {
        freeMemory(data1, n1);
        freeMemory(data2, n2);
        return 1;
    }

    int **res = allocate(n1, m2);
    mult(data1, n1, m1, data2, m2, res);
    output(res, n1, m2);

    freeMemory(data1, n1);
    freeMemory(data2, n2);
    freeMemory(res, n1);
    return 0;
}

void mult(int **matrix_first, int n_first, int m_first, int **matrix_second, int m_second,
          int **matrix_result) {
    for (int i = 0; i < n_first; i++) {
        for (int j = 0; j < m_second; j++) {
            matrix_result[i][j] = 0;
            for (int k = 0; k < m_first; k++) {
                matrix_result[i][j] += matrix_first[i][k] * matrix_second[k][j];
            }
        }
    }
}

int modeSum() {
    int n1 = 0, m1 = 0;
    if (inputNM(&n1, &m1)) {
        return 1;
    }
    int **data1 = allocate(n1, m1);
    if (input(data1, n1, m1)) {
        freeMemory(data1, n1);
        return 1;
    }

    int n2 = 0, m2 = 0;
    if (inputNM(&n2, &m2)) {
        return 1;
    }
    int **data2 = allocate(n2, m2);
    if (input(data2, n2, m2)) {
        freeMemory(data1, n1);
        freeMemory(data2, n2);
        return 1;
    }

    if (n1 != n2 || m1 != m2) {
        freeMemory(data1, n1);
        freeMemory(data2, n2);
        return 1;
    }

    int **res = allocate(n2, m2);

    sum(data1, n1, m2, data2, res);
    output(res, n1, m2);

    freeMemory(data1, n1);
    freeMemory(data2, n2);
    freeMemory(res, n1);
    return 0;
}

void sum(int **matrix_first, int n_first, int m_first, int **matrix_second, int **matrix_result) {
    for (int i = 0; i < n_first; i++) {
        for (int j = 0; j < m_first; j++) {
            matrix_result[i][j] = matrix_first[i][j] + matrix_second[i][j];
        }
    }
}

int inputNM(int *n, int *m) {
    double n1_d, m1_d;
    if (scanf("%lf %lf", &n1_d, &m1_d) != 2 || n1_d != (int)n1_d || m1_d != (int)m1_d || (int)n1_d <= 0 ||
        (int)m1_d <= 0) {
        return 1;
    }
    *n = (int)n1_d, *m = (int)m1_d;
    return 0;
}

int **allocate(int n1, int m1) {
    int **data1 = (int **)malloc(n1 * sizeof(int *));
    for (int i = 0; i < n1; i++) {
        data1[i] = (int *)malloc(m1 * sizeof(int));
    }
    return data1;
}

void freeMemory(int **data, int n) {
    for (int i = 0; i < n; i++) {
        free(data[i]);
    }
    free(data);
}

int input(int **data, int n, int m) {
    double buf_d;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (scanf("%lf", &buf_d) != 1 || buf_d != (int)buf_d) {
                return 1;
            }
            data[i][j] = (int)buf_d;
        }
    }
    return 0;
}

void output(int **data, int n, int m) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (j == m - 1) {
                printf("%d", data[i][j]);
            } else {
                printf("%d ", data[i][j]);
            }
        }
        if (i != n - 1) {
            printf("\n");
        }
    }
}