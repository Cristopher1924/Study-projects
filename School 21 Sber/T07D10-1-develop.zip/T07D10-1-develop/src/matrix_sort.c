#include <stdio.h>
#include <stdlib.h>
#define MAXN 100

int dynam_input(int **data, int n, int m);
void dynam_output(int **data, int n, int m);
int dynam_mode2(int n, int m);
int dynam_mode3(int n, int m);
void free_mode3(int **data, int n);
int dynam_mode4(int n, int m);
void bubbleSort(int **data, int n, int m);

int main() {
    double mode_d;
    if (scanf("%lf", &mode_d) != 1 || mode_d != (int)mode_d || (int)mode_d > 4 || (int)mode_d < 1) {
        printf("n/a");
        return 1;
    }
    int mode = (int)mode_d;

    double n_d, m_d;
    if (scanf("%lf %lf", &n_d, &m_d) != 2 || n_d != (int)n_d || m_d != (int)m_d || (int)n_d <= 0 ||
        (int)m_d <= 0) {
        printf("n/a");
        return 1;
    }
    int n = (int)n_d, m = (int)m_d;
    if (mode == 1 && (n > MAXN || m > MAXN)) {
        printf("n/a");
        return 1;
    }
    switch (mode) {
        case 1:
            if (dynam_mode2(n, m)) {
                printf("n/a");
            }
            break;
        case 2:
            if (dynam_mode3(n, m)) {
                printf("n/a");
            }
            break;
        case 3:
            if (dynam_mode4(n, m)) {
                printf("n/a");
            }
            break;
        default:
            printf("n/a");
            break;
    }
}

void bubbleSort(int **data, int n, int m) {
    int sum1 = 0, sum2 = 0;
    int buf = 0;
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            sum1 = sum2 = 0;
            for (int l = 0; l < m; l++) {
                sum1 += data[j][l];
                sum2 += data[j + 1][l];
            }
            if (sum1 > sum2) {
                for (int l = 0; l < m; l++) {
                    buf = data[j][l];
                    data[j][l] = data[j + 1][l];
                    data[j + 1][l] = buf;
                }
            }
        }
    }
}

int dynam_mode2(int n, int m) {
    int **data = (int **)malloc(n * sizeof(int *) + n * m * sizeof(int));
    int *ptr = (int *)(data + n);
    for (int i = 0; i < m; i++) {
        data[i] = ptr + m * i;
    }
    if (dynam_input(data, n, m)) {
        free(data);
        return 1;
    }
    bubbleSort(data, n, m);
    dynam_output(data, n, m);
    free(data);
    return 0;
}

int dynam_mode3(int n, int m) {
    int **data = (int **)malloc(n * sizeof(int *));
    for (int i = 0; i < n; i++) {
        data[i] = (int *)malloc(m * sizeof(int));
    }
    if (dynam_input(data, n, m)) {
        free_mode3(data, n);
        return 1;
    }
    dynam_output(data, n, m);
    bubbleSort(data, n, m);
    free_mode3(data, n);
    return 0;
}

void free_mode3(int **data, int n) {
    for (int i = 0; i < n; i++) {
        free(data[i]);
    }
    free(data);
}

int dynam_mode4(int n, int m) {
    int **pointer_data = (int **)malloc(n * sizeof(int *));
    int *values_data = (int *)malloc(n * m * sizeof(int));
    for (int i = 0; i < n; i++) {
        pointer_data[i] = values_data + m * i;
    }
    if (dynam_input(pointer_data, n, m)) {
        free(values_data);
        free(pointer_data);
        return 1;
    }
    bubbleSort(pointer_data, n, m);
    dynam_output(pointer_data, n, m);
    free(values_data);
    free(pointer_data);
    return 0;
}

int dynam_input(int **data, int n, int m) {
    double buf_d;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (scanf("%lf", &buf_d) != 1 || buf_d != (int)buf_d) {
                return 1;
            }
            data[i][j] = (int)buf_d;
        }
    }
    return 0;
}

void dynam_output(int **data, int n, int m) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (j == m - 1) {
                printf("%d", data[i][j]);
            } else {
                printf("%d ", data[i][j]);
            }
        }
        if (i != n - 1) {
            printf("\n");
        }
    }
}