#include <stdio.h>
#include <stdlib.h>
#define MAXN 100

void mas_output(int *data, int k);
void stat_output(int data[][MAXN], int n, int m);
int stat_mode1(int data[][MAXN], int n, int m);
void stat_max(int data[][MAXN], int n, int m, int *max);
void stat_min(int data[][MAXN], int n, int m, int *min);
void dynam_max(int **data, int n, int m, int *max);
void dynam_min(int **data, int n, int m, int *min);
int dynam_input(int **data, int n, int m);
void dynam_output(int **data, int n, int m);
int dynam_mode2(int n, int m, int *max, int *min);
int dynam_mode3(int n, int m, int *max, int *min);
void free_mode3(int **data, int n);
int dynam_mode4(int n, int m, int *max, int *min);

int main() {
    double mode_d;
    if (scanf("%lf", &mode_d) != 1 || mode_d != (int)mode_d || (int)mode_d > 4 || (int)mode_d < 1) {
        printf("n/a");
        return 1;
    }
    int mode = (int)mode_d;

    double n_d, m_d;
    if (scanf("%lf %lf", &n_d, &m_d) != 2 || n_d != (int)n_d || m_d != (int)m_d || (int)n_d <= 0 ||
        (int)m_d <= 0) {
        printf("n/a");
        return 1;
    }
    int n = (int)n_d, m = (int)m_d;
    if (mode == 1 && (n > MAXN || m > MAXN)) {
        printf("n/a");
        return 1;
    }
    int data[MAXN][MAXN];
    int *max = (int *)malloc(n * sizeof(int));
    int *min = (int *)malloc(m * sizeof(int));
    switch (mode) {
        case 1:
            if (stat_mode1(data, n, m)) {
                printf("n/a");
                break;
            }
            stat_max(data, n, m, max);
            stat_min(data, n, m, min);
            stat_output(data, n, m);
            printf("\n");
            mas_output(max, n);
            printf("\n");
            mas_output(min, m);
            break;
        case 2:
            if (dynam_mode2(n, m, max, min)) {
                printf("n/a");
            }
            break;
        case 3:
            if (dynam_mode3(n, m, max, min)) {
                printf("n/a");
            }
            break;
        case 4:
            if (dynam_mode4(n, m, max, min)) {
                printf("n/a");
            }
            break;
        default:
            printf("n/a");
            break;
    }
    free(max);
    free(min);
}

void mas_output(int *data, int k) {
    for (int i = 0; i < k - 1; i++) {
        printf("%d ", data[i]);
    }
    printf("%d", data[k - 1]);
}

void dynam_max(int **data, int n, int m, int *max) {
    for (int i = 0; i < n; i++) {
        int buf_max = data[i][0];
        for (int j = 1; j < m; j++) {
            if (buf_max < data[i][j]) {
                buf_max = data[i][j];
            }
        }
        max[i] = buf_max;
    }
}

void dynam_min(int **data, int n, int m, int *min) {
    for (int i = 0; i < m; i++) {
        int buf_min = data[0][i];
        for (int j = 1; j < n; j++) {
            if (buf_min > data[j][i]) {
                buf_min = data[j][i];
            }
        }
        min[i] = buf_min;
    }
}

void stat_max(int data[][MAXN], int n, int m, int *max) {
    for (int i = 0; i < n; i++) {
        int buf_max = data[i][0];
        for (int j = 1; j < m; j++) {
            if (buf_max < data[i][j]) {
                buf_max = data[i][j];
            }
        }
        max[i] = buf_max;
    }
}

void stat_min(int data[][MAXN], int n, int m, int *min) {
    for (int i = 0; i < m; i++) {
        int buf_min = data[0][i];
        for (int j = 1; j < n; j++) {
            if (buf_min > data[j][i]) {
                buf_min = data[j][i];
            }
        }
        min[i] = buf_min;
    }
}

void stat_output(int data[][MAXN], int n, int m) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (j == m - 1) {
                printf("%d", data[i][j]);
            } else {
                printf("%d ", data[i][j]);
            }
        }
        if (i != n - 1) {
            printf("\n");
        }
    }
}

int stat_mode1(int data[][MAXN], int n, int m) {
    double buf_d;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (scanf("%lf", &buf_d) != 1 || buf_d != (int)buf_d) {
                return 1;
            }
            data[i][j] = (int)buf_d;
        }
    }
    return 0;
}

int dynam_mode2(int n, int m, int *max, int *min) {
    int **data = (int **)malloc(n * sizeof(int *) + n * m * sizeof(int));
    int *ptr = (int *)(data + n);
    for (int i = 0; i < m; i++) {
        data[i] = ptr + m * i;
    }
    if (dynam_input(data, n, m)) {
        free(data);
        return 1;
    }
    dynam_output(data, n, m);
    dynam_max(data, n, m, max);
    dynam_min(data, n, m, min);
    printf("\n");
    mas_output(max, n);
    printf("\n");
    mas_output(min, m);
    free(data);
    return 0;
}

int dynam_mode3(int n, int m, int *max, int *min) {
    int **data = (int **)malloc(n * sizeof(int *));
    for (int i = 0; i < n; i++) {
        data[i] = (int *)malloc(m * sizeof(int));
    }
    if (dynam_input(data, n, m)) {
        free_mode3(data, n);
        return 1;
    }
    dynam_output(data, n, m);
    dynam_max(data, n, m, max);
    dynam_min(data, n, m, min);
    printf("\n");
    mas_output(max, n);
    printf("\n");
    mas_output(min, m);
    free_mode3(data, n);
    return 0;
}

void free_mode3(int **data, int n) {
    for (int i = 0; i < n; i++) {
        free(data[i]);
    }
    free(data);
}

int dynam_mode4(int n, int m, int *max, int *min) {
    int **pointer_data = (int **)malloc(n * sizeof(int *));
    int *values_data = (int *)malloc(n * m * sizeof(int));
    for (int i = 0; i < n; i++) {
        pointer_data[i] = values_data + m * i;
    }
    if (dynam_input(pointer_data, n, m)) {
        free(values_data);
        free(pointer_data);
        return 1;
    }
    dynam_output(pointer_data, n, m);
    dynam_max(pointer_data, n, m, max);
    dynam_min(pointer_data, n, m, min);
    printf("\n");
    mas_output(max, n);
    printf("\n");
    mas_output(min, m);
    free(values_data);
    free(pointer_data);
    return 0;
}

int dynam_input(int **data, int n, int m) {
    double buf_d;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (scanf("%lf", &buf_d) != 1 || buf_d != (int)buf_d) {
                return 1;
            }
            data[i][j] = (int)buf_d;
        }
    }
    return 0;
}

void dynam_output(int **data, int n, int m) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (j == m - 1) {
                printf("%d", data[i][j]);
            } else {
                printf("%d ", data[i][j]);
            }
        }
        if (i != n - 1) {
            printf("\n");
        }
    }
}