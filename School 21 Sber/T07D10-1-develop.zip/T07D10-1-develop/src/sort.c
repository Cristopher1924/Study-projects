#include <stdio.h>
#include <stdlib.h>

int input(int *data, int n);
void output(int *data, int n);
void bubbleSort(int *data, int n);
void swap(int *a, int *b);

int main() {
    double n_d;
    if (scanf("%lf", &n_d) != 1 || n_d != (int)n_d || (int)n_d <= 0) {
        printf("n/a");
        return 1;
    }
    int n = (int)n_d;
    int *data = (int *)malloc(n * sizeof(int));
    if (input(data, n)) {
        free(data);
        printf("n/a");
        return 1;
    };
    bubbleSort(data, n);
    output(data, n);
    free(data);
    return 0;
}

int input(int *data, int n) {
    double buf_d;
    for (int i = 0; i < n; ++i) {
        if (scanf("%lf", &buf_d) != 1 || (int)buf_d != buf_d) {
            return 1;
        }
        data[i] = (int)buf_d;
    }
    return 0;
}

void output(int *data, int n) {
    for (int i = 0; i < n; ++i) {
        printf("%d ", data[i]);
    }
}

void bubbleSort(int *data, int n) {
    for (int i = 0; i < n - 1; ++i) {
        for (int j = 0; j < n - i - 1; j++) {
            if (data[j] > data[j + 1]) {
                swap(data + j, data + j + 1);
            }
        }
    }
}

void swap(int *a, int *b) {
    int buf = *a;
    *a = *b;
    *b = buf;
}