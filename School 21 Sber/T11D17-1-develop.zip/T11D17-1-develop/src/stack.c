#include "stack.h"

#include <stdio.h>
#include <stdlib.h>

void init(Stack* stack) { stack->top = NULL; }

int isEmpty(Stack* stack) { return stack->top == NULL; }

void push(Stack* stack, int value) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = value;
    newNode->next = stack->top;
    stack->top = newNode;
}

int pop(Stack* stack) {
    if (isEmpty(stack)) {
        printf("Stack is empty.\n");
        return -1;
    }
    int value = stack->top->data;
    Node* temp = stack->top;
    stack->top = stack->top->next;
    free(temp);
    return value;
}

void destroy(Stack* stack) {
    while (!isEmpty(stack)) {
        pop(stack);
    }
}

void print_stack(Stack* stack) {
    Node* current = stack->top;
    while (current != NULL) {
        printf("%d\n", current->data);
        current = current->next;
    }
}
