#include "list.h"

#include <stdio.h>
#include <stdlib.h>

#define DOORS_COUNT 15

struct node* init(struct door* door) {
    struct node* root;
    root = (struct node*)malloc(sizeof(struct node));
    root->value = *door;
    root->next = NULL;
    return root;
}

struct node* add_door(struct node* elem, struct door* door) {
    struct node *temp, *buf;
    temp = (struct node*)malloc(sizeof(struct node));
    buf = elem->next;
    elem->next = temp;
    temp->value = *door;
    temp->next = buf;
    return temp;
}

struct node* find_door(int door_id, struct node* root) {
    struct node* temp;
    temp = root;
    while (temp->value.id != door_id) {
        temp = temp->next;
    }
    return temp;
}

struct node* remove_door(struct node* elem, struct node* root) {
    struct node* temp;
    temp = root;
    while (temp->next != elem) {
        temp = temp->next;
    }
    temp->next = elem->next;
    free(elem);
    return temp;
}

void destroy(struct node* root) {
    struct node *temp, *next;
    temp = root;
    while (temp != NULL) {
        next = temp->next;
        free(temp);
        temp = next;
    }
}

void print_doors(struct node* root) {
    struct node* temp;
    temp = root;
    do {
        printf("%d, %d\n", temp->value.id, temp->value.status);
        temp = temp->next;
    } while (temp != NULL);
}

int count_doors(struct node* root) {
    int counter = 0;
    struct node* temp;
    temp = root;
    while (temp != NULL) {
        temp = temp->next;
        counter++;
    }
    return counter;
}