#include "list.h"

#include <stdio.h>
#include <stdlib.h>

int add_door_test() {
    struct door *door1, *door2, *door3;
    door1 = (struct door *)malloc(sizeof(struct door));
    door2 = (struct door *)malloc(sizeof(struct door));
    door3 = (struct door *)malloc(sizeof(struct door));
    door1->id = 1, door1->status = 0;
    door2->id = 2, door2->status = 1;
    door3->id = 3, door3->status = 0;

    struct node *root = init(door1);
    printf("Start list: \n");
    print_doors(root);
    printf("\nAdded \"2, 1\" element after root:\n");

    add_door(root, door2);
    print_doors(root);
    printf("\nAdded \"3, 0\" element after root:\n");
    add_door(root, door3);
    print_doors(root);

    int res = 0;
    if (count_doors(root) == 3) {
        res++;
    }

    destroy(root);
    free(door1);
    free(door2);
    free(door3);
    return res;
}

int remove_door_test() {
    struct door *door1, *door2, *door3;
    door1 = (struct door *)malloc(sizeof(struct door));
    door2 = (struct door *)malloc(sizeof(struct door));
    door3 = (struct door *)malloc(sizeof(struct door));
    door1->id = 1, door1->status = 0;
    door2->id = 2, door2->status = 1;
    door3->id = 3, door3->status = 0;

    struct node *root = init(door1);
    printf("Start list:\n");
    add_door(root, door2);
    add_door(root, door3);
    print_doors(root);
    printf("\nDeleted \"2, 1\" element: \n");

    struct node *door2_node = find_door(2, root);
    remove_door(door2_node, root);
    print_doors(root);
    printf("\nDeleted \"3, 0\" element: \n");

    struct node *door3_node = find_door(3, root);
    remove_door(door3_node, root);
    print_doors(root);

    int res = 0;
    if (count_doors(root) == 1) {
        res++;
    }

    destroy(root);
    free(door1);
    free(door2);
    free(door3);
    return res;
}

int main() {
    add_door_test() ? printf("\nResult: SUCCESS\n") : printf("\nResult: FAIL\n");
    printf("----------------------------------------------------\n");
    remove_door_test() ? printf("\nResult: SUCCESS") : printf("\nResult: FAIL");
}