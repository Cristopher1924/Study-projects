#include "stack.h"

#include <stdio.h>
#include <stdlib.h>

int stack_push_test() {
    Stack stack;
    init(&stack);

    printf("Pushed 5:\n");
    push(&stack, 5);
    print_stack(&stack);

    printf("\nPushed 10:\n");
    push(&stack, 10);
    print_stack(&stack);

    printf("\nPushed 15:\n");
    push(&stack, 15);
    print_stack(&stack);

    int res = 0;
    if (pop(&stack) == 15 && pop(&stack) == 10 && pop(&stack) == 5) {
        res++;
    }

    destroy(&stack);

    return res;
}

int stack_pop_test() {
    Stack stack;
    init(&stack);

    push(&stack, 5);
    push(&stack, 10);
    push(&stack, 15);
    printf("Start:\n");
    print_stack(&stack);

    printf("\nPopped:\n");
    int popped1 = pop(&stack);
    print_stack(&stack);
    printf("\nPopped:\n");
    int popped2 = pop(&stack);
    print_stack(&stack);
    int popped3 = pop(&stack);

    destroy(&stack);

    int res = 0;
    if (popped1 == 15 && popped2 == 10 && popped3 == 5) {
        res++;
    }

    return res;
}

int main() {
    stack_push_test() ? printf("\nResult: SUCCESS\n") : printf("\nResult: FAIL\n");
    printf("----------------------------------------------------\n");
    stack_pop_test() ? printf("\nResult: SUCCESS") : printf("\nResult: FAIL");
    return 0;
}