typedef struct Node {
    int data;
    struct Node* next;
} Node;

typedef struct {
    Node* top;
} Stack;

void init(Stack* stack);
int isEmpty(Stack* stack);
void push(Stack* stack, int value);
int pop(Stack* stack);
void destroy(Stack* stack);
void print_stack(Stack* stack);