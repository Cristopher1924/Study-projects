#include <math.h>
#include <stdio.h>

int res(int a);
int isPrime(int n);
int compl(int a, int del);
int abs(int a);

int main() {
    double d_a;
    if (!scanf("%lf", &d_a)) {
        printf("n/a");
        return -1;
    }
    if (d_a != (int)d_a) {
        printf("n/a");
        return -1;
    }

    int i_a = (int)d_a;
    if (i_a == 1 || i_a == -1) {
        printf("n/a");
        return -1;
    }
    int result = res(i_a);
    if (result) {
        printf("%d", result);
        return 0;
    } else {
        printf("n/a");
        return -1;
    }
}

int res(int a) {
    a = abs(a);
    for (int i = a; i > 0; i--) {
        if (compl(a, i) && isPrime(i)) {
            return i;
        }
    }
    return 0;
}

int isPrime(int n) {
    for (int i = 2; i <= sqrt(n); i++) {
        if (compl(n, i)) {
            return 0;
        }
    }
    return 1;
}

int compl(int a, int del) {
    int n = a;
    while (n > 0) {
        n -= del;
    }
    if (n == 0) {
        return 1;
    } else {
        return 0;
    }
}

int abs(int a) {
    if (a > 0) {
        return a;
    } else {
        return -a;
    }
}