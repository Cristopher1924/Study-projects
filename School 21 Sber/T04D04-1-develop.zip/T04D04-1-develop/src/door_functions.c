// От -пи до +пи включительно. Точность пи - 20 знаков.
// Всего 42 замера.
// Первый столбец - ось абсцисс, второй, третьий и четвертый - значения функций в точке. Разделитель - |
// Точность всех значений - 7 знаков после запятой.

#include <math.h>
#include <stdio.h>

double agnesi(double x) { return 1 / (1 + pow(x, 2)); }

double bernoulli(double x) {
    double kor1 = sqrt(1 + 4 * x * x * 1);
    double kor2 = sqrt(kor1 - x * x - 1);
    if (!isnan(kor2)) {
        return kor2;
    }
    return 0;
}

double hyperbola(double x) { return 1 / pow(x, 2); }

int main() {
    double pi = 3.14159265358979323846;
    double step = (pi + pi) / 41.0;

    for (double i = -pi; i < pi; i += step) {
        double bern = bernoulli(i);
        if (bern) {
            printf("%.7lf | %.7lf | %.7lf | %.7lf\n", i, agnesi(i), bern, hyperbola(i));
        } else {
            printf("%.7lf | %.7lf | - | %.7lf\n", i, agnesi(i), hyperbola(i));
        }
    }

    return 0;
}