#include <math.h>
#include <stdio.h>

int hexToInt(char symbol) {
    if (symbol == '0') {
        return 0;
    } else if (symbol == '1') {
        return 1;
    } else if (symbol == '2') {
        return 2;
    } else if (symbol == '3') {
        return 3;
    } else if (symbol == '4') {
        return 4;
    } else if (symbol == '5') {
        return 5;
    } else if (symbol == '6') {
        return 6;
    } else if (symbol == '7') {
        return 7;
    } else if (symbol == '8') {
        return 8;
    } else if (symbol == '9') {
        return 9;
    } else if (symbol == 'A') {
        return 10;
    } else if (symbol == 'B') {
        return 11;
    } else if (symbol == 'C') {
        return 12;
    } else if (symbol == 'D') {
        return 13;
    } else if (symbol == 'E') {
        return 14;
    } else if (symbol == 'F') {
        return 15;
    }
    return -1;
}

char numToASCII(char ch1, char ch2) {
    int a = hexToInt(ch1);
    int b = hexToInt(ch2);
    int num = a * 16 + b;
    return (char)num;
}

int ASCIIToNum(char ch) { return (int)ch; }

int main(int argc, char *argv[]) {
    if (argc != 2) {
        printf("n/a");
        return -1;
    }

    char *arg = argv[1];

    if (arg[0] == '0') {
        char ch1, ch2;
        scanf("%c", &ch1);
        if (ch1 == '\n') {
            printf("n/a");
            return -1;
        }
        scanf("%c", &ch2);

        while (ch1 != '\n') {
            if (ch1 == ' ' && ch2 != ' ') {
                printf("%X ", ASCIIToNum(ch2));
            } else if (ch1 != ' ' && ch2 == ' ') {
                printf("%X ", ASCIIToNum(ch1));
            } else if (ch1 != ' ' && ch2 == '\n') {
                printf("%X", ASCIIToNum(ch1));
                return -1;
            } else {
                printf("n/a");
                return -1;
            }
            scanf("%c%c", &ch1, &ch2);
        }

    } else if (arg[0] == '1') {
        char ch1, ch2, sep;

        while (scanf("%c%c%c", &ch1, &ch2, &sep)) {
            if (sep != '\n' && sep != ' ') {
                printf("n/a");
                return -1;
            } else if (sep == '\n') {
                printf("%c", numToASCII(ch1, ch2));
                return -1;
            } else if (sep == ' ') {
                printf("%c ", numToASCII(ch1, ch2));
            } else {
                printf("n/a");
                return -1;
            }
        }
    } else {
        printf("n/a");
        return -1;
    }
}