#include <stdio.h>

int fib(int n) {
    if (n == 1 || n == 2) {
        return 1;
    }
    return fib(n - 1) + fib(n - 2);
}

int main() {
    double d_n;
    if (!scanf("%lf", &d_n) || d_n != (int)d_n) {
        printf("n/a");
        return -1;
    }
    int n = (int)d_n;
    if (n == 0) {
        printf("0");
        return -1;
    }
    if (n < 0) {
        printf("n/a");
        return -1;
    }
    printf("%d", fib(n));

    return 0;
}