#include <stdio.h>
#define NMAX 10

int input(int *a, int *n);
void output(int *a, int n);
void squaring(int *a, int n);

int main() {
    int n, data[NMAX];
    if (input(data, &n)) {
        printf("n/a");
        return 1;
    };
    squaring(data, n);
    output(data, n);

    return 0;
}

int input(int *a, int *n) {
    double n_d, buf_d;
    if (scanf("%lf", &n_d) != 1 || (int)n_d != n_d) {
        return 1;
    };
    *n = (int)n_d;
    if (*n > NMAX || *n < 0) {
        return 1;
    }
    for (int i = 0; i < *n; ++i) {
        if (scanf("%lf", &buf_d) != 1 || (int)buf_d != buf_d) {
            return 1;
        }
        a[i] = (int)buf_d;
    }
    return 0;
}

void output(int *a, int n) {
    for (int i = 0; i < n; ++i) {
        printf("%d ", a[i]);
    }
}

void squaring(int *a, int n) {
    for (int i = 0; i < n; ++i) {
        a[i] = a[i] * a[i];
    }
}
