#include <math.h>
#include <stdio.h>
#define NMAX 30

int input(int *a, int *n);
void output(int *a, int n);
double mean(int *a, int n);
double variance(int *a, int n);
int result(int *a, int n);

int main() {
    int n, data[NMAX];
    if (input(data, &n)) {
        printf("n/a");
        return 1;
    };
    result(data, n);
    return 0;
}

int input(int *a, int *n) {
    double n_d, buf_d;
    if (scanf("%lf", &n_d) != 1 || (int)n_d != n_d) {
        return 1;
    };
    *n = (int)n_d;
    if (*n > NMAX || *n <= 0) {
        return 1;
    }
    for (int i = 0; i < *n; ++i) {
        if (scanf("%lf", &buf_d) != 1 || (int)buf_d != buf_d) {
            return 1;
        }
        a[i] = (int)buf_d;
    }
    return 0;
}

void output(int *a, int n) {
    for (int i = 0; i < n; ++i) {
        printf("%d ", a[i]);
    }
}

double mean(int *a, int n) {
    double res = 0.0;
    for (int i = 0; i < n; i++) {
        res += a[i];
    }
    return res / n;
}

double variance(int *a, int n) {
    double mean_current = mean(a, n);
    double res = 0.0;
    for (int i = 0; i < n; i++) {
        res += (a[i] - mean_current) * (a[i] - mean_current);
    }
    return res / n;
}

int result(int *a, int n) {
    double mean_cur = mean(a, n);
    double variance_cur = variance(a, n);
    for (int i = n - 1; i >= 0; --i) {
        if (a[i] % 2 == 0 && a[i] >= mean_cur && a[i] <= (mean_cur + 3 * sqrt(variance_cur)) && a[i] != 0) {
            printf("%d", a[i]);
            return 0;
        }
    }
    printf("0");
    return 1;
}