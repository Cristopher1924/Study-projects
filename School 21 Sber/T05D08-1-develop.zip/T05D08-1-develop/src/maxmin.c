#include <stdio.h>

void maxmin(int prob1, int prob2, int prob3, int *max, int *min);

/* Find a max & min probabilities */
int main() {
    double x_d, y_d, z_d;
    if (scanf("%lf %lf %lf", &x_d, &y_d, &z_d) != 3 || (int)x_d != x_d || (int)y_d != y_d ||
        (int)z_d != z_d) {
        printf("n/a");
        return 1;
    }
    int x = (int)x_d, y = (int)y_d, z = (int)z_d;
    int max, min;

    maxmin(x, y, z, &max, &min);

    printf("%d %d", max, min);

    return 0;
}

/* This function should be kept !!! (Your AI) */
/* But errors & bugs should be fixed         */
void maxmin(int prob1, int prob2, int prob3, int *max, int *min) {
    *max = *min = prob1;

    if (prob2 > *max) *max = prob2;
    if (prob2 < *min) *min = prob2;

    if (prob3 > *max) *max = prob3;
    if (prob3 < *min) *min = prob3;
}
