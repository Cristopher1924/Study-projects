#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "clear_state.h"

#define NMAX 100

int main() {
    int numberLines = 0;
    char fileAddress[NMAX];
    char searchString[11];
    if (scanf("%s %s", fileAddress, searchString) != 2) {
        printf("n/a");
        return 1;
    }
    FILE* file = fopen(fileAddress, "r+b");

    if (!file) {
        printf("n/a");
        return 1;
    }
    if (countLines(file, &numberLines)) {
        fclose(file);
        return 1;
    }
    // printf("%d\n", numberLines);
    int res = findLines(file, searchString, numberLines);
    if (res) {
        printf("%d", res);
    } else {
        printf("!n/a");
    }
    fclose(file);
}

int findLines(FILE* file, char* searchString, int countLines) {
    int res = 0;
    for (int i = 0; i < countLines; i++) {
        struct Line line = readLine(file, i);
        char fromFileString[11];
        snprintf(fromFileString, sizeof(fromFileString), "%02d.%02d.%04d", line.day, line.month, line.year);
        if (strcmp(fromFileString, searchString) == 0) {
            res++;
        }
    }
    return res;
}

struct Line readLine(FILE* file, int index) {
    int offset = index * sizeof(struct Line);
    fseek(file, offset, SEEK_SET);
    struct Line record;
    fread(&record, sizeof(struct Line), 1, file);
    rewind(file);
    return record;
}

int countLines(FILE* file, int* countLines) {
    struct Line line;
    int flag = 0;
    while (fread(&line, sizeof(struct Line), 1, file)) {
        (*countLines)++;
    }
    if (!(*countLines)) {
        printf("n/a");
        flag++;
    }
    return flag;
}