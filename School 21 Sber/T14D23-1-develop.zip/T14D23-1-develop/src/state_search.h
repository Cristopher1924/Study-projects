#include <stdio.h>

struct Line {
    int year;
    int month;
    int day;
    int hour;
    int minute;
    int second;
    int status;
    int code;
};

int findLines(FILE* file, char* searchString, int countLines);
int countLines(FILE* file, int* countLines);
struct Line readLine(FILE* file, int index);