#include "clear_state.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define NMAX 100

int main() {
    int numberLines = 0;
    int counter = 0;
    char fileAddress[NMAX];
    if (scanf("%s", fileAddress) != 1) {
        printf("n/a");
        return 1;
    }
    FILE* file = fopen(fileAddress, "r+b");

    if (!file) {
        printf("n/a");
        return 1;
    }
    if (countLines(file, &numberLines)) {
        fclose(file);
        return 1;
    }
    // printf("%d\n", numberLines);

    int day1 = 0, month1 = 0, year1 = 0, day2 = 0, month2 = 0, year2 = 0;
    char ch1, ch2, ch3, ch4, ch5;
    if (scanf("%d%c%d%c%d%c%d%c%d%c%d", &day1, &ch1, &month1, &ch2, &year1, &ch3, &day2, &ch4, &month2, &ch5,
              &year2) == 11 &&
        day1 >= 1 && day1 <= 31 && ch1 == '.' && ch2 == '.' && ch4 == '.' && ch5 == '.' && ch3 == ' ' &&
        month1 >= 1 && month1 <= 12 && year1 >= 0 && (day2 >= day1 || month2 >= month1 || year2 >= year1) &&
        day2 <= 31 && month2 <= 12) {
        FILE* file2 = fopen("test", "ab");
        for (int i = 0; i < numberLines; i++) {
            struct Line line = readLine(file, i);
            if (dateInRange(line, year1, year2, month1, month2, day1, day2)) {
                continue;
            } else {
                writeLine(file2, &line, i);
                counter++;
            }
        }
        printAllLines(file2, counter);
        rename("test", fileAddress);
        fclose(file2);
        FILE* fil3 = fopen(fileAddress, "r");
        printAllLines(fil3, counter);
        fclose(fil3);
    } else {
        printf("n/a");
    }
    fclose(file);
}

int dateInRange(struct Line line, int startYear, int endYear, int startMonth, int endMonth, int startDay,
                int endDay) {
    int res = 0;
    if ((line.year > startYear ||
         (line.year == startYear &&
          (line.month > startMonth || (line.month == startMonth && line.day >= startDay)))) &&
        (line.year < endYear || (line.year == endYear && line.month < endMonth) ||
         (line.year == endYear && line.month == endMonth && line.day <= endDay)))
        res = 1;
    else
        res = 0;
    return res;
}

int findLines(FILE* file, char* searchString, int countLines) {
    int res = 0;
    for (int i = 0; i < countLines; i++) {
        struct Line line = readLine(file, i);
        char fromFileString[11];
        snprintf(fromFileString, sizeof(fromFileString), "%02d.%02d.%04d", line.day, line.month, line.year);
        if (strcmp(fromFileString, searchString) == 0) {
            res++;
        }
    }
    return res;
}

struct Line readLine(FILE* file, int index) {
    int offset = index * sizeof(struct Line);
    fseek(file, offset, SEEK_SET);
    struct Line record;
    fread(&record, sizeof(struct Line), 1, file);
    rewind(file);
    return record;
}

int countLines(FILE* file, int* countLines) {
    struct Line line;
    int flag = 0;
    while (fread(&line, sizeof(struct Line), 1, file)) {
        (*countLines)++;
    }
    if (!(*countLines)) {
        printf("n/a");
        flag++;
    }
    return flag;
}

void writeLine(FILE* file, const struct Line* lineToWrite, int index) {
    int offset = index * sizeof(struct Line);
    fseek(file, offset, SEEK_SET);
    fwrite(lineToWrite, sizeof(struct Line), 1, file);
    fflush(file);
    rewind(file);
}

void printAllLines(FILE* file, int countLines) {
    for (int i = 0; i < countLines; i++) {
        struct Line line = readLine(file, i);
        printf("%d %d %d %d %d %d %d %d", line.year, line.month, line.day, line.hour, line.minute,
               line.second, line.status, line.code);
        if (i != countLines - 1) {
            printf("\n");
        }
    }
}