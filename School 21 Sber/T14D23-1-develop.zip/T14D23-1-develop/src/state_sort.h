#include <stdio.h>

struct Line {
    int year;
    int month;
    int day;
    int hour;
    int minute;
    int second;
    int status;
    int code;
};

int getMode(int* mode);
int countLines(FILE* file, int* countLines);
void printAllLines(FILE* file, int countLines);
struct Line readLine(FILE* file, int index);
void bubbleSort(FILE* file, int countLines);
int compareLines(struct Line line1, struct Line line2);
void swapLines(FILE* file, int index1, int index2);
void writeLine(FILE* file, const struct Line* lineToWrite, int index);