#include <stdio.h>

struct Line {
    int year;
    int month;
    int day;
    int hour;
    int minute;
    int second;
    int status;
    int code;
};

int findLines(FILE* file, char* searchString, int countLines);
int countLines(FILE* file, int* countLines);
struct Line readLine(FILE* file, int index);
void removeLinesInDateRange(FILE* file, char* fromDate, char* toDate, int countLines);
void printAllLines(FILE* file, int countLines);
void writeLine(FILE* file, const struct Line* lineToWrite, int index);
int dateInRange(struct Line line, int startYear, int endYear, int startMonth, int endMonth, int startDay,
                int endDay);