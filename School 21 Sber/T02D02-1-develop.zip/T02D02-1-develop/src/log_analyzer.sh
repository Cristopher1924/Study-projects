#!/bin/bash

# lines=$(wc files.log | awk '{print $1}')
# echo $lines
if [ -f files.log ]; then
    files=()
    shas256=()
    val=0
    while read line
    do
        file=$(echo $line | cut -d' ' -f1)
        sha256=$(echo $line | cut -d' ' -f8)
        files+=($file)
        shas256+=($sha256)
        let val++
    done < files.log 
    count=$(echo "${files[@]}" | tr ' ' '\n' | sort -u | wc -l)
    echo $val
    echo $count
    # val=$(echo "${files[@]}" | tr ' ' '\n' | wc -l)
    for i in $(seq 0 $((val-1))); do
        for j in $(seq $((i+1)) $val); do
            # echo "$i $j"
            # echo "${files[$i]} ${files[$j]}"
            # echo "${shas256[$i]} ${shas256[$j]}"
            if [[ ${files[$i]} == ${files[$j]} ]]; then
                if [[ ${shas256[$i]} != ${shas256[$j]} ]]; then
                    let k++
                fi
                break
            fi
        done
    done
    echo $k
else
    echo "File files.log does not exist."
fi