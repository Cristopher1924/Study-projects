#!/bin/bash

echo "Input path: "
read folder
echo "Input a string, which you want to be changed: "
read line
echo "Input a string, on which you want to change: "
read string

if [ -f "$folder" ]; then

    sed -i '' 's/'$line'/'$string'/g' $folder

    filesize=$(wc -c $folder | awk '{print $1}')
    now=$(date +"%Y-%m-%d %H:%M")
    sha256=$(shasum -a 256 $folder | awk '{print $1}')
    echo ""$folder" - "$filesize" - "$now" - "$sha256" - sha256" >> files.log
else
    echo "File $folder does not exist."
fi