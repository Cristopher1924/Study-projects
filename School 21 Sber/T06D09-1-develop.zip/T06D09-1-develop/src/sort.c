#include <stdio.h>

int input(int *data);
void output(int *data);
void bubbleSort(int *data);
void swap(int *a, int *b);

int main() {
    int data[10];
    if (input(data)) {
        printf("n/a");
        return 1;
    };
    bubbleSort(data);
    // quickSort(data, 0, 9);
    output(data);
}

int input(int *data) {
    double buf_d;
    for (int i = 0; i < 10; ++i) {
        if (scanf("%lf", &buf_d) != 1 || (int)buf_d != buf_d) {
            return 1;
        }
        data[i] = (int)buf_d;
    }
    return 0;
}

void output(int *data) {
    for (int i = 0; i < 10 - 1; ++i) {
        printf("%d ", data[i]);
    }
    printf("%d", data[9]);
}

void bubbleSort(int *data) {
    for (int i = 0; i < 10 - 1; ++i) {
        for (int j = 0; j < 10 - i - 1; j++) {
            if (data[j] > data[j + 1]) {
                swap(data + j, data + j + 1);
            }
        }
    }
}

void swap(int *a, int *b) {
    int buf = *a;
    *a = *b;
    *b = buf;
}