#include <stdio.h>

#define LEN 100

void sum(int *buff1, int len1, int *buff2, int len2, int *result, int *result_length);
void sub(int *buff1, int len1, int *buff2, int len2, int *result, int *result_length);
int input(int *num, int *n);
void output(int *num, int n);
int max(int a, int b);
int min(int a, int b);
void reverse(int *res, int *resres, int resn, int *resresn);
void outputSub(int *num, int n);

int main() {
    int num1[LEN], num2[LEN], res[LEN + 1], resres[LEN + 1], res1[LEN + 1], resres1[LEN + 1];
    int n1 = 0, n2 = 0, resn = 0, resresn = 0, resn1 = 0, resresn1 = 0;
    int flag = 0;
    if (input(num1, &n1) || input(num2, &n2)) {
        printf("n/a");
        return 0;
    }
    sum(num1, n1, num2, n2, res, &resn);
    reverse(res, resres, resn, &resresn);
    output(resres, resresn);
    printf("\n");
    if (n1 < n2) {
        printf("n/a");
        return 0;
    } else if (n1 == n2) {
        for (int i = 0; i < n1; i++) {
            if (num1[i] < num2[i] && flag == 0) {
                printf("n/a");
                return 0;
            } else if (num1[i] > num2[i]) {
                flag = 1;
            }
        }
    }
    sub(num1, n1, num2, n2, res1, &resn1);
    reverse(res1, resres1, resn1, &resresn1);
    outputSub(resres1, resresn1);
}

void reverse(int *res, int *resres, int resn, int *resresn) {
    int start = resn - 1;
    int k = 0;
    *resresn = resn;

    if (res[resn] != 0) {
        start += 1;
        *resresn = resn + 1;
    }
    for (int i = start; i >= 0; i--) {
        resres[k] = res[i];
        k++;
    }
}

int input(int *num, int *n) {
    double buf_d;
    char c;
    do {
        if (scanf("%lf%c", &buf_d, &c) != 2 || buf_d != (int)buf_d || (int)buf_d > 9 || (int)buf_d < 0) {
            return 1;
        }
        num[*n] = (int)buf_d;
        (*n)++;
    } while (!(c == '\n' || c == EOF));
    return 0;
}

void output(int *num, int n) {
    int flag = 0;
    int flagp = 0;
    if (num[0] <= 0) {
        for (int i = 1; i < n; i++) {
            if (num[i] <= 0) {
                if (flag) {
                    printf("%d ", num[i]);
                    flagp = 1;
                }
            } else {
                flag = 1;
                printf("%d ", num[i]);
                flagp = 1;
            }
        }
    } else {
        for (int i = 0; i < n; i++) {
            printf("%d ", num[i]);
            flagp = 1;
        }
    }
    if (!flagp) {
        printf("0");
    }
    // for (int i = 0; i < n; ++i) {
    //     printf("%d ", num[i]);
    // }
}
void outputSub(int *num, int n) {
    int flagp = 0;
    int flag = 0;
    if (num[0] <= 0) {
        for (int i = 1; i < n; i++) {
            if (num[i] <= 0) {
                if (flag) {
                    printf("%d ", num[i]);
                    flagp = 1;
                }
            } else {
                flag = 1;
                printf("%d ", num[i]);
                flagp = 1;
            }
        }
    } else {
        for (int i = 0; i < n; i++) {
            printf("%d ", num[i]);
            flagp = 1;
        }
    }
    if (!flagp) {
        printf("0");
    }
}

void sum(int *num1, int n1, int *num2, int n2, int *res, int *resn) {
    int k1 = n1 - 1;
    int k2 = n2 - 1;
    for (int i = 0; i < max(n1, n2); i++) {
        if (k1 < 0 || k2 < 0) {
            int summa = k1 < 0 ? num2[k2] + res[i] : num1[k1] + res[i];
            // printf("\nSumma: %d", summa);
            if (summa > 9) {
                res[i] = summa - (summa / 10) * 10;
                res[i + 1] += 1;
            } else {
                res[i] = summa;
            }
        } else {
            int summa = num1[k1] + num2[k2] + res[i];
            if (summa > 9) {
                res[i] = summa - (summa / 10) * 10;
                res[i + 1] += 1;
            } else {
                res[i] = summa;
            }
            // printf("!!!!%d", summa);
        }
        // printf("\n%d %d %d\n", num1[k1], num2[k2], res[i]);
        k1--, k2--;
        *resn += 1;
    }
}

void sub(int *num1, int n1, int *num2, int n2, int *res, int *resn) {
    int k1 = n1 - 1;
    int k2 = n2 - 1;

    for (int i = 0; i < max(n1, n2); i++) {
        if (k2 < 0) {
            int diff = num1[k1] + res[i];
            if (diff < 0) {
                res[i + 1] -= 1;
                res[i] = 10 + res[i];
            } else {
                res[i] = diff;
            }
            // printf("\n!!!!%d %d\n", num1[k1], res[i]);
        } else {
            int diff = num1[k1] - num2[k2];

            if (diff < 0) {
                res[i] += 10 + num1[k1] - num2[k2];
                res[i + 1] -= 1;
            } else {
                res[i] += diff;
            }
            // printf("\n%d %d %d\n", num1[k1], num2[k2], res[i]);
        }
        k1--, k2--;
        *resn += 1;
    }
}

int max(int a, int b) { return a > b ? a : b; }

int min(int a, int b) { return a < b ? a : b; }