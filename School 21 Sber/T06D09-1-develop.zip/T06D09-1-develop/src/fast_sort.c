#include <stdio.h>

#define N 10
#define root i + sh
#define lefts 2 * i + 1 + sh
#define rights 2 * i + 2 + sh

int input(int *data);
void output(int *data);
void quickSort(int *data, int first, int last);
void swap(int *a, int *b);
int heapSort(int *data, int n);
void copy(int *data, int *data2, int n);

int main() {
    int data[N], data2[N], data3[N];
    if (input(data)) {
        printf("n/a");
        return 1;
    };
    copy(data, data2, N);
    copy(data, data3, N);
    heapSort(data2, N);
    output(data2);
    printf("\n");
    quickSort(data3, 0, N - 1);
    output(data3);
}

void copy(int *data, int *data2, int n) {
    for (int i = 0; i < n; i++) {
        data2[i] = data[i];
    }
}

int input(int *data) {
    double buf_d;
    for (int i = 0; i < N; ++i) {
        if (scanf("%lf", &buf_d) != 1 || (int)buf_d != buf_d) {
            return 1;
        }
        data[i] = (int)buf_d;
    }
    return 0;
}

void output(int *data) {
    for (int i = 0; i < 10 - 1; ++i) {
        printf("%d ", data[i]);
    }
    printf("%d", data[9]);
}

void quickSort(int *data, int first, int last) {
    if (first < last) {
        int left = first, right = last, middle = data[(left + right) / 2];
        do {
            while (data[left] < middle) {
                left++;
            }
            while (data[right] > middle) {
                right--;
            }
            if (left <= right) {
                swap(data + left, data + right);
                left++;
                right--;
            }
        } while (left <= right);
        quickSort(data, first, right);
        quickSort(data, left, last);
    }
}

int heapSort(int *data, int n) {
    int b = 0, sh = 0;
    while (1) {
        b = 0;
        for (int i = 0; i < n; ++i) {
            if (rights < n) {
                if (data[root] > data[lefts] || data[root] > data[rights]) {
                    if (data[lefts] < data[rights]) {
                        swap(&data[root], &data[lefts]);
                        b = 1;
                    } else if (data[rights] < data[lefts]) {
                        swap(&data[root], &data[rights]);
                        b = 1;
                    }
                }
            } else if (lefts < n) {
                if (data[root] > data[lefts]) {
                    swap(&data[root], &data[lefts]);
                    b = 1;
                }
            }
        }
        if (!b) {
            sh++;
        }
        if (sh + 2 == n) {
            return 0;
        }
    }
    return 0;
}

void swap(int *a, int *b) {
    int buf = *a;
    *a = *b;
    *b = buf;
}