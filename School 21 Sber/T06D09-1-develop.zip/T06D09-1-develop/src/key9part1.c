/*------------------------------------
        Здравствуй, человек!
        Чтобы получить ключ
        поработай с комментариями.
-------------------------------------*/

#include <stdio.h>

int input(int *buffer, int *length);
void output(int *buffer, int length);
int sum_numbers(int *buffer, int length);
int find_numbers(int *buffer, int length, int number, int *numbers);

/*------------------------------------
        Функция получает массив данных
        через stdin.
        Выдает в stdout особую сумму
        и сформированный массив
        специальных элементов
        (выбранных с помощью найденной суммы):
        это и будет частью ключа
-------------------------------------*/
int main() {
    int data[10], numbers[10], n;
    if (input(data, &n)) {
        printf("n/a");
        return 1;
    };
    int number = sum_numbers(data, n);
    if (number == 0) {
        printf("n/a");
        return 1;
    }
    printf("%d\n", number);
    int k = find_numbers(data, n, number, numbers);
    output(numbers, k);
}

int input(int *buffer, int *length) {
    double n_d, buf_d;
    if (scanf("%lf", &n_d) != 1 || (int)n_d != n_d) {
        return 1;
    };
    *length = (int)n_d;
    if (*length > 10 || *length <= 0) {
        return 1;
    }
    for (int i = 0; i < *length; ++i) {
        if (scanf("%lf", &buf_d) != 1 || (int)buf_d != buf_d) {
            return 1;
        }
        buffer[i] = (int)buf_d;
    }
    return 0;
}

void output(int *buffer, int length) {
    for (int i = 0; i < length - 1; ++i) {
        printf("%d ", buffer[i]);
    }
    printf("%d", buffer[length - 1]);
}

int sum_numbers(int *buffer, int length) {
    int sum = 0;

    for (int i = 0; i < length; i++) {
        if (buffer[i] % 2 == 0) {
            sum += buffer[i];
        }
    }

    return sum;
}

/*------------------------------------
        Функция должна находить
        все элементы, на которые нацело
        делится переданное число и
        записывает их в выходной массив.
-------------------------------------*/
int find_numbers(int *buffer, int length, int number, int *numbers) {
    int k = 0;
    for (int i = 0; i < length; i++) {
        if (buffer[i] == 0) {
            continue;
        }
        if (number % buffer[i] == 0) {
            numbers[k] = buffer[i];
            k++;
        }
    }
    return k;
}
