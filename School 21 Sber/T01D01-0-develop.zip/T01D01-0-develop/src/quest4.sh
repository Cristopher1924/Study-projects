ps
kill 16480