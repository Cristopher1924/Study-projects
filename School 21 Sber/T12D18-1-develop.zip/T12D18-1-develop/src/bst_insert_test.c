#include <stdio.h>

#include "bst.h"

void bst_create_test() {
    int n1 = 4, n2 = 6, n3 = 7, n4 = 8;
    t_btree *tree1 = bstree_create_node(5);
    t_btree *tree2 = bstree_create_node(5);

    bstree_insert(tree1, n1, compare_values);
    bstree_insert(tree1, n2, compare_values);

    bstree_print(tree1, 0);
    tree1->left->item == 4 ? printf("\nResult: SUCCCESS") : printf("\nResult: FAIL");

    printf("\n--------------------------------------\n");

    bstree_insert(tree2, n3, compare_values);
    bstree_insert(tree2, n2, compare_values);
    bstree_insert(tree2, n4, compare_values);
    bstree_insert(tree2, n1, compare_values);

    bstree_print(tree2, 0);
    tree2->right->right->item == 8 ? printf("\nResult: SUCCCESS") : printf("\nResult: FAIL");

    bstree_free(tree1);
    bstree_free(tree2);
}

int main() { bst_create_test(); }