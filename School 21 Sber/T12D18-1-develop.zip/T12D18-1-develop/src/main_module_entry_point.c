#include <stdio.h>
#include <stdlib.h>

#include "documentation_module.h"
#include "print_module.h"

int main() {
#ifdef PRINT
    print_log(print_char, Module_load_success_message);
#endif
#ifdef DOCS
    print_documents(Documents_count, Documents);
#endif
    return 0;
}
