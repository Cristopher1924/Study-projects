#include <stdio.h>

#include "bst.h"

void bst_create_test() {
    int test1 = 1, test2 = 2;
    t_btree *tree1 = bstree_create_node(test1);
    t_btree *tree2 = bstree_create_node(test2);

    printf("Input value: %d\n", test1);
    printf("\nOutput head: %d\n", tree1->item);
    tree1->left == NULL ? printf("Left item: NULL\n") : printf("Left item: %d\n", tree1->left->item);
    tree1->right == NULL ? printf("Right item: NULL\n") : printf("Right item: %d\n", tree1->right->item);
    tree1->item == test1 ? printf("\nResult: SUCCESS\n") : printf("\nResult: FAIL\n");
    printf("--------------------------------------------\n");
    printf("Input value: %d\n", test2);
    printf("\nOutput head: %d\n", tree2->item);
    tree2->left == NULL ? printf("Left item: NULL\n") : printf("Left item: %d\n", tree2->left->item);
    tree2->right == NULL ? printf("Right item: NULL\n") : printf("Right item: %d\n", tree2->right->item);
    tree2->item == test2 ? printf("\nResult: SUCCESS\n") : printf("\nResult: FAIL\n");

    bstree_free(tree1);
    bstree_free(tree2);
}

int main() { bst_create_test(); }