#include "documentation_module.h"

#include <stdarg.h>
#include <stdlib.h>

int validate(char* data) {
    int validation_result = !strcmp(data, Available_document);
    return validation_result;
}

int* check_available_documentation_module(int (*validate)(char*), int document_count, ...) {
    va_list args;
    va_start(args, document_count);

    int* availability_mask = (int*)malloc(document_count * sizeof(int));

    for (int i = 0; i < document_count; i++) {
        char* document_name = va_arg(args, char*);
        availability_mask[i] = validate(document_name);
    }

    va_end(args);
    return availability_mask;
}

void print_documents(int document_count, ...) {
    va_list args;
    va_start(args, document_count);

    int* availability_mask = check_available_documentation_module(validate, Documents_count, Documents);

    for (int i = 0; i < document_count; i++) {
        char* document_name = va_arg(args, char*);
        printf("%-15s : %s\n", document_name, availability_mask[i] ? "available" : "unavailable");
    }
    va_end(args);
    free(availability_mask);
}