#include "bst.h"

#include <stdio.h>
#include <stdlib.h>

t_btree *bstree_create_node(int item) {
    t_btree *new_node = (t_btree *)malloc(sizeof(t_btree));
    new_node->item = item;
    new_node->left = NULL;
    new_node->right = NULL;
    return new_node;
}

t_btree *bstree_insert(t_btree *root, int item, int (*cmpf)(int, int)) {
    if (root == NULL) {
        return bstree_create_node(item);
    } else if (cmpf(item, root->item)) {
        root->right = bstree_insert(root->right, item, cmpf);
    } else {
        root->left = bstree_insert(root->left, item, cmpf);
    }
    return root;
}

int compare_values(int item, int temp) { return item > temp ? 1 : 0; }

void bstree_print(t_btree *root, int level) {
    if (root == NULL) {
        return;
    }
    bstree_print(root->right, level + 1);
    for (int i = 0; i < level; i++) {
        printf("   ");
    }
    printf("%d\n", root->item);
    bstree_print(root->left, level + 1);
}

void apply(int value) { printf(" %d", value); }

void bstree_apply_infix(t_btree *root, void (*applyf)(int)) {
    if (root != NULL) {
        bstree_apply_infix(root->left, applyf);
        applyf(root->item);
        bstree_apply_infix(root->right, applyf);
    }
}

void bstree_apply_prefix(t_btree *root, void (*applyf)(int)) {
    if (root != NULL) {
        applyf(root->item);
        bstree_apply_prefix(root->left, applyf);
        bstree_apply_prefix(root->right, applyf);
    }
}

void bstree_apply_postfix(t_btree *root, void (*applyf)(int)) {
    if (root != NULL) {
        bstree_apply_postfix(root->left, applyf);
        bstree_apply_postfix(root->right, applyf);
        applyf(root->item);
    }
}

void bstree_free(t_btree *root) {
    if (root == NULL) {
        return;
    }
    bstree_free(root->left);
    bstree_free(root->right);
    free(root);
}