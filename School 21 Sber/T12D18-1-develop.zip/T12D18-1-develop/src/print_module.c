#include "print_module.h"

#include <stdio.h>
#include <time.h>

char print_char(char ch) { return putchar(ch); }

void print_log(char (*print)(char), char* message) {
    for (int i = 0; i < 5; i++) {
        print(Log_prefix[i]);
    }
    print(' ');
    print_time();
    print(' ');
    int iter = 0;
    char ch = message[iter];
    do {
        print(ch);
        iter++;
        ch = message[iter];
    } while (ch != '\n');
}

void print_time() {
    time_t now;
    time(&now);
    struct tm* local = localtime(&now);

    int hours = local->tm_hour;
    int minutes = local->tm_min;
    int seconds = local->tm_sec;
    printf("%02d:%02d:%02d", hours, minutes, seconds);
}
