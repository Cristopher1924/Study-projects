#include "state_sort.h"

#include <stdio.h>
#include <stdlib.h>

#define NMAX 100

int main() {
    int numberLines = 0, mode = 0;
    char fileAddress[NMAX];
    double y_d, m_d, d_d, h_d, min_d, s_d, stat_d, c_d;
    if (scanf("%s", fileAddress) != 1) {
        printf("n/a");
        return 1;
    }
    FILE* file = fopen(fileAddress, "r+b");

    if (!file) {
        printf("n/a");
        return 1;
    }
    if (countLines(file, &numberLines)) {
        fclose(file);
        return 1;
    }
    // printf("%d\n", numberLines);

    if (getMode(&mode)) {
        fclose(file);
        return 1;
    }

    switch (mode) {
        case 0:
            printAllLines(file, numberLines);
            break;
        case 1:
            bubbleSort(file, numberLines);
            printAllLines(file, numberLines);
            break;
        case 2:

            if (scanf("%lf %lf %lf %lf %lf %lf %lf %lf", &y_d, &m_d, &d_d, &h_d, &min_d, &s_d, &stat_d,
                      &c_d) != 8 ||
                y_d != (int)y_d || m_d != (int)m_d || d_d != (int)d_d || h_d != (int)h_d ||
                min_d != (int)min_d || s_d != (int)s_d || stat_d != (int)stat_d || c_d != (int)c_d) {
                printf("n/a");
            } else {
                struct Line lineToWrite;
                lineToWrite.year = (int)y_d, lineToWrite.month = (int)m_d, lineToWrite.day = (int)d_d,
                lineToWrite.hour = (int)h_d, lineToWrite.minute = (int)min_d, lineToWrite.second = (int)s_d,
                lineToWrite.status = (int)stat_d, lineToWrite.code = (int)c_d;
                writeLine(file, &lineToWrite, numberLines);
                bubbleSort(file, numberLines + 1);
                printAllLines(file, numberLines + 1);
            }
            break;
        default:
            printf("n/a");
            break;
    }
    fclose(file);
}

struct Line readLine(FILE* file, int index) {
    int offset = index * sizeof(struct Line);
    fseek(file, offset, SEEK_SET);
    struct Line record;
    fread(&record, sizeof(struct Line), 1, file);
    rewind(file);
    return record;
}

int getMode(int* mode) {
    double mode_d;
    int flag = 0;
    if (scanf("%lf", &mode_d) != 1 || mode_d != (int)mode_d) {
        printf("n/a");
        flag++;
    } else {
        *mode = (int)mode_d;
    }
    return flag;
}

int countLines(FILE* file, int* countLines) {
    struct Line line;
    int flag = 0;
    while (fread(&line, sizeof(struct Line), 1, file)) {
        (*countLines)++;
    }
    if (!(*countLines)) {
        printf("n/a");
        flag++;
    }
    return flag;
}

void printAllLines(FILE* file, int countLines) {
    for (int i = 0; i < countLines; i++) {
        struct Line line = readLine(file, i);
        printf("%d %d %d %d %d %d %d %d", line.year, line.month, line.day, line.hour, line.minute,
               line.second, line.status, line.code);
        if (i != countLines - 1) {
            printf("\n");
        }
    }
}

void bubbleSort(FILE* file, int countLines) {
    for (int i = 0; i < countLines - 1; i++) {
        for (int j = 0; j < countLines - 1 - i; j++) {
            struct Line line1 = readLine(file, j);
            struct Line line2 = readLine(file, j + 1);
            if (compareLines(line1, line2) > 0) {
                swapLines(file, j, j + 1);
            }
        }
    }
}

int compareLines(struct Line line1, struct Line line2) {
    if (line1.year != line2.year) return line1.year - line2.year;
    if (line1.month != line2.month) return line1.month - line2.month;
    if (line1.day != line2.day) return line1.day - line2.day;
    if (line1.hour != line2.hour) return line1.hour - line2.hour;
    if (line1.minute != line2.minute) return line1.minute - line2.minute;
    if (line1.second != line2.second) return line1.second - line2.second;
    if (line1.status != line2.status) return line1.status - line2.status;
    return line1.code - line2.code;
}

void swapLines(FILE* file, int index1, int index2) {
    struct Line line1 = readLine(file, index1);
    struct Line line2 = readLine(file, index2);

    writeLine(file, &line1, index2);
    writeLine(file, &line2, index1);
}

void writeLine(FILE* file, const struct Line* lineToWrite, int index) {
    int offset = index * sizeof(struct Line);
    fseek(file, offset, SEEK_SET);
    fwrite(lineToWrite, sizeof(struct Line), 1, file);
    fflush(file);
    rewind(file);
}