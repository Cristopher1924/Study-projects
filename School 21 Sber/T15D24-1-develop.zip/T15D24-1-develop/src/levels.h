#ifndef LEVELS_H
#define LEVELS_H

#include <stdio.h>

typedef struct {
    int memoryLevel;
    int cellCount;
    int protectionFlag;
} LEVELS;

LEVELS readLineLevels(FILE* file, int index);
int countLinesLevels(FILE* file);
void printAllLinesLevels(FILE* file, int countLines);
int levelsControl();
LEVELS getNewLineLevels();
void updateLevels(FILE* dbFile, int count);
void insertLevels(FILE* dbfile, LEVELS* lineToWrite, int index);
int removeLevels(FILE* dbFile, int count);

#endif