#ifndef STATUS_EVENTS_H
#define STATUS_EVENTS_H

#include <stdio.h>

typedef struct {
    int eventId;
    int moduleId;
    int newStatus;
    char changeDate[11];
    char changeTime[9];
} STATUS_EVENTS;

STATUS_EVENTS readLineStatusEvents(FILE* file, int index);
int countLinesStatusEvents(FILE* file);
void printAllLinesStatusEvents(FILE* file, int countLines);
int statusEventsControl();
STATUS_EVENTS getNewLineStatusEvents();
void updateStatusEvents(FILE* dbFile, int count);
void insertStatusEvents(FILE* dbfile, STATUS_EVENTS* lineToWrite, int index);
int removeStatusEvents(FILE* dbFile, int count);
STATUS_EVENTS changeStatus(int newStatus, int eventId, int moduleId);

#endif