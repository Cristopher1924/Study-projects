#include "shared.h"

#include <stdio.h>
#include <time.h>

#include "levels.h"
#include "modules.h"
#include "status_events.h"

int showTables() {
    int isError = 0;
    FILE *modulesFile = fopen(modulesPath, "rb");
    FILE *levelsFile = fopen(levelsPath, "rb");
    FILE *statusEventsFile = fopen(statusEventsPath, "rb");
    if (!modulesFile || !levelsFile || !statusEventsFile) {
        isError++;
    } else {
        printAllLinesModules(modulesFile, countLinesModules(modulesFile));
        printf("\n--------------------------------------------------------------------------------------\n");
        printAllLinesLevels(levelsFile, countLinesLevels(levelsFile));
        printf("\n--------------------------------------------------------------------------------------\n");
        printAllLinesStatusEvents(statusEventsFile, countLinesStatusEvents(statusEventsFile));
        fclose(modulesFile);
        fclose(levelsFile);
        fclose(statusEventsFile);
    }
    return isError;
}

void makeAllActiveInactiveModules() {
    FILE *dbFile = fopen(statusEventsPath, "r+w+b");
    int count = countLinesStatusEvents(dbFile);
    int moduleId;
    STATUS_EVENTS line;
    STATUS_EVENTS newLine;
    for (int i = 1; i < count; i++) {
        line = readLineStatusEvents(dbFile, i);
        if (line.newStatus == 1) {
            newLine = changeStatus(0, line.eventId, line.moduleId);
            insertStatusEvents(dbFile, &newLine, countLinesStatusEvents(dbFile));
            moduleId = line.moduleId;
            deleteRecord(moduleId);
        }
    }
    fclose(dbFile);
}

void deleteRecord(int moduleId) {
    FILE *dbFile = fopen(modulesPath, "r+w+b");
    int count = countLinesModules(dbFile);
    MODULES line;
    for (int i = 0; i < count; i++) {
        line = readLineModules(dbFile, i);
        if (line.moduleId == moduleId) {
            line.deletionFlag = 1;
            insertModules(dbFile, &line, i);
        }
    }
    fclose(dbFile);
}

void makeMainModuleSafe() {
    FILE *dbFile = fopen(statusEventsPath, "r+w+b");
    int count = countLinesStatusEvents(dbFile);
    STATUS_EVENTS line = changeStatus(0, count, 0);
    insertStatusEvents(dbFile, &line, count);
    count++;
    STATUS_EVENTS line2 = changeStatus(1, count, 0);
    insertStatusEvents(dbFile, &line2, count);
    count++;
    STATUS_EVENTS line3 = changeStatus(20, count, 0);
    insertStatusEvents(dbFile, &line3, count);

    LEVELS lineLevels;
    FILE *dbFileLevels = fopen(levelsPath, "r+w+b");
    int countLevels = countLinesLevels(dbFileLevels);
    for (int i = 0; i < countLevels; i++) {
        lineLevels = readLineLevels(dbFileLevels, i);
        if (lineLevels.memoryLevel == 1) {
            lineLevels.protectionFlag = 1;
            insertLevels(dbFileLevels, &lineLevels, i);
        }
    }

    FILE *dbFileModules = fopen(modulesPath, "r+w+b");
    MODULES lineModules;
    int countModules = countLinesModules(dbFileModules);
    for (int i = 0; i < countModules; i++) {
        lineModules = readLineModules(dbFileModules, i);
        if (lineModules.moduleId == 0) {
            lineModules.memoryLevel = 1;
            lineModules.deletionFlag = 0;
            insertModules(dbFileModules, &lineModules, i);
        }
    }

    fclose(dbFileLevels);
    fclose(dbFile);
}
