#ifndef MODULES_H
#define MODULES_H

#include <stdio.h>

typedef struct {
    int moduleId;
    char name[30];
    int memoryLevel;
    int cellNumber;
    int deletionFlag;
} MODULES;

MODULES readLineModules(FILE* file, int index);
int countLinesModules(FILE* file);
void printAllLinesModules(FILE* file, int countLines);
int modulesControl();
MODULES getNewLineModules();
void insertModules(FILE* dbfile, MODULES* lineToWrite, int index);
void updateModules(FILE* dbFile, int count);
int removeModules(FILE* dbFile, int count);

#endif