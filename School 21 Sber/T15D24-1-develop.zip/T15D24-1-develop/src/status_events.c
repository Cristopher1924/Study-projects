#include "status_events.h"

#include <stdio.h>
#include <string.h>
#include <time.h>

#include "modules.h"
#include "modules_db.h"
#include "shared.h"

STATUS_EVENTS readLineStatusEvents(FILE* file, int index) {
    int offset = index * sizeof(STATUS_EVENTS);
    fseek(file, offset, SEEK_SET);
    STATUS_EVENTS record;
    fread(&record, sizeof(STATUS_EVENTS), 1, file);
    rewind(file);
    return record;
}

int countLinesStatusEvents(FILE* file) {
    STATUS_EVENTS line;
    int res = 0;
    while (fread(&line, sizeof(STATUS_EVENTS), 1, file)) {
        res++;
    }
    return res;
}

void printAllLinesStatusEvents(FILE* file, int countLines) {
    printf("%10s | %10s | %10s | %11s | %9s\n", "Event Id", "Module Id", "New Status", "Change Date",
           "Change Time");
    for (int i = 0; i < countLines; i++) {
        STATUS_EVENTS line = readLineStatusEvents(file, i);
        printf("%10d | %10d | %10d | %11s | %9s\n", line.eventId, line.moduleId, line.newStatus,
               line.changeDate, line.changeTime);
    }
}

int statusEventsControl() {
    FILE* dbFile = fopen(statusEventsPath, "r+w+b");
    STATUS_EVENTS lineToWrite;
    int mode;
    int count = countLinesStatusEvents(dbFile);
    int flag = 0;
    printMenu(3);

    int isError = getMode(&mode);
    while (isError == 0 && mode != -1) {
        switch (mode) {
            case 0:
                printAllLinesStatusEvents(dbFile, count);
                printf("\nCOUNT: %d\n", count);
                break;
            case 1:
                lineToWrite = getNewLineStatusEvents();
                lineToWrite.eventId = count;
                insertStatusEvents(dbFile, &lineToWrite, count);
                count++;
                break;
            case 2:
                updateStatusEvents(dbFile, count);
                break;
            case 3:
                flag = removeStatusEvents(dbFile, count);
                fclose(dbFile);
                rename("tmp", statusEventsPath);
                dbFile = fopen(statusEventsPath, "rwb");
                count -= flag;
                break;
            default:
                return isError;
        }
        printMenu(3);
        isError = getMode(&mode);
    }

    return isError;
}

STATUS_EVENTS getNewLineStatusEvents() {
    STATUS_EVENTS lineToWrite;
    lineToWrite.eventId = 1;
    lineToWrite.moduleId = 1;
    lineToWrite.newStatus = 1;
    printf("\nEnter module id: ");
    scanf("%d", &lineToWrite.moduleId);
    printf("\nEnter new status: ");
    scanf("%d", &lineToWrite.newStatus);
    printf("\nEnter change date (yyyy-mm-dd): ");
    scanf("%11s", lineToWrite.changeDate);
    printf("\nEnter change time (hh:mm:ss): ");
    scanf("%9s", lineToWrite.changeTime);
    return lineToWrite;
}

void updateStatusEvents(FILE* dbFile, int count) {
    int id;
    int idx = 0;
    printf("Enter event id: ");
    scanf("%d", &id);
    STATUS_EVENTS line;
    for (int i = 0; i < count; i++) {
        line = readLineStatusEvents(dbFile, i);
        if (line.eventId == id) {
            break;
        }
        idx++;
    }
    STATUS_EVENTS lineToWrite = getNewLineStatusEvents();
    lineToWrite.eventId = id;
    insertStatusEvents(dbFile, &lineToWrite, idx);
}

void insertStatusEvents(FILE* dbfile, STATUS_EVENTS* lineToWrite, int index) {
    int offset = index * sizeof(STATUS_EVENTS);
    fseek(dbfile, offset, SEEK_SET);
    fwrite(lineToWrite, sizeof(STATUS_EVENTS), 1, dbfile);
    fflush(dbfile);
    rewind(dbfile);
}

int removeStatusEvents(FILE* dbFile, int count) {
    int id;
    FILE* tempFile = fopen("tmp", "w+b");
    printf("Enter event id: ");
    scanf("%d", &id);
    int flag = 0;
    STATUS_EVENTS line;
    for (int i = 0; i < count; i++) {
        line = readLineStatusEvents(dbFile, i);
        if (line.eventId == id) {
            flag++;
            continue;
        }
        insertStatusEvents(tempFile, &line, i - flag);
    }
    fclose(tempFile);
    return flag;
}

STATUS_EVENTS changeStatus(int newStatus, int eventId, int moduleId) {
    STATUS_EVENTS line;
    line.eventId = eventId;
    line.moduleId = moduleId;

    time_t rawtime;
    struct tm* timeinfo;
    char dateNow[11];
    char timeNow[9];
    time(&rawtime);
    timeinfo = localtime(&rawtime);
    strftime(dateNow, sizeof(dateNow), "%d.%m.%Y", timeinfo);
    strftime(timeNow, sizeof(timeNow), "%H:%M:%S", timeinfo);

    sprintf(line.changeDate, dateNow);
    sprintf(line.changeTime, timeNow);
    line.newStatus = newStatus;
    return line;
}