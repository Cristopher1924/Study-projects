#include "levels.h"

#include <stdio.h>
#include <string.h>

#include "modules.h"
#include "modules_db.h"
#include "shared.h"

LEVELS readLineLevels(FILE* file, int index) {
    int offset = index * sizeof(LEVELS);
    fseek(file, offset, SEEK_SET);
    LEVELS record;
    fread(&record, sizeof(LEVELS), 1, file);
    rewind(file);
    return record;
}

int countLinesLevels(FILE* file) {
    LEVELS line;
    int res = 0;
    while (fread(&line, sizeof(LEVELS), 1, file)) {
        res++;
    }
    return res;
}

void printAllLinesLevels(FILE* file, int countLines) {
    printf("%14s | %10s | %15s\n", "Memory Level", "Cell Count", "Protection Flag");
    for (int i = 0; i < countLines; i++) {
        LEVELS line = readLineLevels(file, i);
        printf("%14d | %10d | %15d\n", line.memoryLevel, line.cellCount, line.protectionFlag);
    }
}

int levelsControl() {
    FILE* dbFile = fopen(levelsPath, "r+w+b");
    LEVELS lineToWrite;
    int mode;
    int count = countLinesLevels(dbFile);
    int flag = 0;
    printMenu(3);

    int isError = getMode(&mode);
    while (isError == 0 && mode != -1) {
        switch (mode) {
            case 0:
                printAllLinesLevels(dbFile, count);
                printf("\nCOUNT: %d\n", count);
                break;
            case 1:
                lineToWrite = getNewLineLevels();
                insertLevels(dbFile, &lineToWrite, count);
                count++;
                break;
            case 2:
                updateLevels(dbFile, count);
                break;
            case 3:
                flag = removeLevels(dbFile, count);
                fclose(dbFile);
                rename("tmp", levelsPath);
                dbFile = fopen(levelsPath, "rwb");
                count -= flag;
                break;
            default:
                return isError;
        }
        printMenu(3);
        isError = getMode(&mode);
    }

    return isError;
}

LEVELS getNewLineLevels() {
    LEVELS lineToWrite;
    printf("\nEnter memory level: ");
    scanf("%d", &lineToWrite.memoryLevel);
    printf("\nEnter cell count: ");
    scanf("%d", &lineToWrite.cellCount);
    printf("\nEnter protection flag: ");
    scanf("%d", &lineToWrite.protectionFlag);
    return lineToWrite;
}

void updateLevels(FILE* dbFile, int count) {
    int id;
    printf("Enter memory level: ");
    scanf("%d", &id);
    int idx = 0;
    LEVELS line;
    for (int i = 0; i < count; i++) {
        line = readLineLevels(dbFile, i);
        if (line.memoryLevel == id) {
            break;
        }
        idx++;
    }
    LEVELS lineToWrite = getNewLineLevels();
    insertLevels(dbFile, &lineToWrite, idx);
}

void insertLevels(FILE* dbfile, LEVELS* lineToWrite, int index) {
    int offset = index * sizeof(LEVELS);
    fseek(dbfile, offset, SEEK_SET);
    fwrite(lineToWrite, sizeof(LEVELS), 1, dbfile);
    fflush(dbfile);
    rewind(dbfile);
}

int removeLevels(FILE* dbFile, int count) {
    int id;
    FILE* tempFile = fopen("tmp", "w+b");
    printf("Enter memory level: ");
    scanf("%d", &id);
    int flag = 0;
    LEVELS line;
    for (int i = 0; i < count; i++) {
        line = readLineLevels(dbFile, i);
        if (line.memoryLevel == id) {
            flag++;
            continue;
        }
        insertLevels(tempFile, &line, i - flag);
    }
    fclose(tempFile);
    return flag;
}