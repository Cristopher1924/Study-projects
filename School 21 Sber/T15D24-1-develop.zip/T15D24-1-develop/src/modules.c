#include "modules.h"

#include <stdio.h>
#include <string.h>

#include "modules_db.h"
#include "shared.h"

MODULES readLineModules(FILE* file, int index) {
    int offset = index * sizeof(MODULES);
    fseek(file, offset, SEEK_SET);
    MODULES record;
    fread(&record, sizeof(MODULES), 1, file);
    rewind(file);
    return record;
}

int countLinesModules(FILE* file) {
    MODULES line;
    int res = 0;
    while (fread(&line, sizeof(MODULES), 1, file)) {
        res++;
    }
    return res;
}

void printAllLinesModules(FILE* file, int countLines) {
    printf("%10s | %30s | %14s | %14s | %14s\n", "Module Id", "Name", "Memory Level", "Cell Number",
           "Deletion Flag");
    for (int i = 0; i < countLines; i++) {
        MODULES line = readLineModules(file, i);
        printf("%10d | %30s | %14d | %14d | %14d\n", line.moduleId, line.name, line.memoryLevel,
               line.cellNumber, line.deletionFlag);
    }
}

int modulesControl() {
    FILE* dbFile = fopen(modulesPath, "r+w+b");
    MODULES lineToWrite;
    int mode;
    int count = countLinesModules(dbFile);
    int flag = 0;
    printMenu(3);

    int isError = getMode(&mode);
    while (isError == 0 && mode != -1) {
        switch (mode) {
            case 0:
                printAllLinesModules(dbFile, count);
                printf("\nCOUNT: %d\n", count);
                break;
            case 1:
                lineToWrite = getNewLineModules(count);
                lineToWrite.moduleId = count;
                insertModules(dbFile, &lineToWrite, count);
                count++;
                break;
            case 2:
                updateModules(dbFile, count);
                break;
            case 3:
                flag = removeModules(dbFile, count);
                fclose(dbFile);
                rename("tmp", modulesPath);
                dbFile = fopen(modulesPath, "rwb");
                count -= flag;
                break;
            default:
                return isError;
        }
        printMenu(3);
        isError = getMode(&mode);
    }

    return isError;
}

MODULES getNewLineModules() {
    MODULES lineToWrite;
    lineToWrite.cellNumber = 1;
    lineToWrite.deletionFlag = 1;
    lineToWrite.memoryLevel = 1;
    lineToWrite.moduleId = 1;
    char str[30];
    getchar();
    printf("\nEnter name: ");
    fgets(str, sizeof(str), stdin);
    if (strlen(str) > 0 && str[strlen(str) - 1] == '\n') {
        str[strlen(str) - 1] = '\0';
    }
    sprintf(lineToWrite.name, "%s", str);
    printf("\nEnter memory level: ");
    scanf("%d", &lineToWrite.memoryLevel);
    printf("\nEnter cell number: ");
    scanf("%d", &lineToWrite.cellNumber);
    printf("\nEnter delete status: ");
    scanf("%d", &lineToWrite.deletionFlag);
    return lineToWrite;
}

void updateModules(FILE* dbFile, int count) {
    int id;
    printf("Enter id: ");
    scanf("%d", &id);
    int idx = 0;
    MODULES line;
    for (int i = 0; i < count; i++) {
        line = readLineModules(dbFile, i);
        if (line.moduleId == id) {
            break;
        }
        idx++;
    }
    MODULES lineToWrite = getNewLineModules();
    lineToWrite.moduleId = id;
    insertModules(dbFile, &lineToWrite, idx);
}

void insertModules(FILE* dbfile, MODULES* lineToWrite, int index) {
    int offset = index * sizeof(MODULES);
    fseek(dbfile, offset, SEEK_SET);
    fwrite(lineToWrite, sizeof(MODULES), 1, dbfile);
    fflush(dbfile);
    rewind(dbfile);
}

int removeModules(FILE* dbFile, int count) {
    int id;
    FILE* tempFile = fopen("tmp", "w+b");
    printf("Enter id: ");
    scanf("%d", &id);
    int flag = 0;
    MODULES line;
    for (int i = 0; i < count; i++) {
        line = readLineModules(dbFile, i);
        if (line.moduleId == id) {
            flag++;
            continue;
        }
        insertModules(tempFile, &line, i - flag);
    }
    fclose(tempFile);
    return flag;
}