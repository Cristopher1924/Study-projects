#include "modules_db.h"

#include <stdio.h>

#include "levels.h"
#include "modules.h"
#include "shared.h"
#include "status_events.h"

int main() {
    int mode;
    printMenu(1);
    int isError = getMode(&mode);
    while (isError == 0 && mode != -1) {
        switch (mode) {
            case 0:
                printMenu(2);
                isError += getMode(&mode);
                if (mode == 0) {
                    isError += modulesControl();
                } else if (mode == 1) {
                    isError += levelsControl();
                } else if (mode == 2) {
                    isError += statusEventsControl();
                }
                break;
            case 1:
                isError += showTables();
                break;
            case 2:
                makeAllActiveInactiveModules();
                break;
            case 3:
                makeMainModuleSafe();
                break;
            default:
                break;
        }
        printMenu(1);
        if (!isError) {
            isError += getMode(&mode);
        }
    }
}

int getMode(int* mode) {
    double mode_d;
    int isError = 0;
    if (scanf("%lf", &mode_d) != 1 || mode_d != (int)mode_d) {
        printf("n/a");
        isError++;
    } else {
        *mode = (int)mode_d;
    }
    return isError;
}

void printMenu(int mode) {
    if (mode == 1) {
        printf(
            "===============================\n0 - SELECT TABLE\n1 - SHOW TABLES\n2 - MAKE ALL ACTIVE "
            "INACTIVE AND DELETE THEM\n3 - MAKE MAIN MODULE SAFE\n-1 - "
            "EXIT\n===============================\n");
    } else if (mode == 2) {
        printf(
            "===============================\n0 - MODULE\n1 - LEVELS\n2 - "
            "STATUS_EVENTS\n===============================\n");
    } else if (mode == 3) {
        printf(
            "===============================\n"
            "0 - SHOW LEVELS\n1 - INSERT LEVEL\n"
            "2 - UPDATE LEVEL\n3 - REMOVE LEVEL\n-1 - BACK\n"
            "===============================\n");
    }
}