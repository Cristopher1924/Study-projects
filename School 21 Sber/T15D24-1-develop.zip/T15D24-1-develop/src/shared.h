#ifndef SHARED_H
#define SHARED_H

#define modulesPath "../materials/master_modules.db"
#define levelsPath "../materials/master_levels.db"
#define statusEventsPath "../materials/master_status_events.db"

int showTables();
void makeAllActiveInactiveModules();
void deleteRecord(int moduleId);
void makeMainModuleSafe();

#endif