#ifndef MODULES_DB_H
#define MODULES_DB_H

int getMode(int* mode);
void printMenu();

#endif