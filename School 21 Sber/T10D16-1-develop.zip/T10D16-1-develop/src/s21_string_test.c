#include "s21_string.h"

#include <stdio.h>
#include <stdlib.h>

void outputString(char *str, int n) {
    for (int i = 0; i < n; i++) {
        printf("%c", str[i]);
    }
}

void s21_strlen_test() {
    char *test1, *test2, *test3;
    int n1 = 6, n2 = 0, n3 = 1;
    test1 = malloc(n1 * sizeof(char));
    *test1 = 'p', test1[1] = 'r', test1[2] = 'i', test1[3] = 'v', test1[4] = 'e', test1[5] = 't';
    test2 = malloc(n2 * sizeof(char));
    test3 = malloc(n3 * sizeof(char));
    *test3 = 's';

    // Test 1
    printf("Input: %s", test1);
    int res1 = s21_strlen(test1);
    printf("\nOutput: %d\n", res1);
    res1 == n1 ? printf("Result: SUCCESS") : printf("Result: FAIL");
    printf("\n\n");

    // Test 2
    printf("Input: %s", test2);
    int res2 = s21_strlen(test2);
    printf("\nOutput: %d\n", res2);
    res2 == n2 ? printf("Result: SUCCESS") : printf("Result: FAIL");
    printf("\n\n");

    // Test 3
    printf("Input: %s", test3);
    int res3 = s21_strlen(test3);
    printf("\nOutput: %d\n", res3);
    res3 == n3 ? printf("Result: SUCCESS") : printf("Result: FAIL");

    free(test1);
    free(test2);
    free(test3);
}

void s21_strcmp_test() {
    char *test1, *test2, *test3, *test4;
    int n1 = 6, n2 = 0, n3 = 6, n4 = 6;
    test1 = malloc(n1 * sizeof(char));
    *test1 = 'p', test1[1] = 'r', test1[2] = 'i', test1[3] = 'v', test1[4] = 'e', test1[5] = 't';
    test2 = malloc(n2 * sizeof(char));
    test3 = malloc(n3 * sizeof(char));
    test4 = malloc(n4 * sizeof(char));
    *test3 = 'p', test3[1] = 'r', test3[2] = 'i', test3[3] = 'v', test3[4] = 'e', test3[5] = 't';
    *test4 = 'p', test4[1] = 'r', test4[2] = 'i', test4[3] = 'v', test4[4] = 'e', test4[5] = 'l';

    // Test 1
    printf("Input: %s %s", test1, test3);
    int res1 = s21_strcmp(test1, test3);
    printf("\nOutput: %d\n", res1);
    res1 == 0 ? printf("Result: SUCCESS") : printf("Result: FAIL");
    printf("\n\n");

    // Test 2
    printf("Input: %s %s", test2, test2);
    int res2 = s21_strcmp(test2, test2);
    printf("\nOutput: %d\n", res2);
    res2 == 0 ? printf("Result: SUCCESS") : printf("Result: FAIL");
    printf("\n\n");

    // Test 3
    printf("Input: %s %s", test1, test4);
    int res3 = s21_strcmp(test1, test4);
    printf("\nOutput: %d\n", res3);
    res3 == 1 ? printf("Result: SUCCESS") : printf("Result: FAIL");
    printf("\n\n");

    // Test 4
    printf("Input: %s %s", test4, test1);
    int res4 = s21_strcmp(test4, test1);
    printf("\nOutput: %d\n", res4);
    res4 == -1 ? printf("Result: SUCCESS") : printf("Result: FAIL");

    free(test1);
    free(test2);
    free(test3);
    free(test4);
}

void s21_strcpy_test() {
    char *test1, *test2, *test3;
    char *test1new, *test2new, *test3new;
    int n1 = 6, n2 = 0, n3 = 1;
    test1 = malloc(n1 * sizeof(char));
    *test1 = 'p', test1[1] = 'r', test1[2] = 'i', test1[3] = 'v', test1[4] = 'e', test1[5] = 't';
    test2 = malloc(n2 * sizeof(char));
    test3 = malloc(n3 * sizeof(char));
    *test3 = 's';
    test1new = malloc(n1 * sizeof(char));
    test2new = malloc(n2 * sizeof(char));
    test3new = malloc(n3 * sizeof(char));

    // Test 1
    printf("Input: %s", test1);
    char *res1 = s21_strcpy(test1new, test1);
    printf("\nOutput: %s", res1);
    s21_strcmp(test1, test1new) == 0 ? printf("\nResult: SUCCESS") : printf("\nResult: FAIL");
    printf("\n\n");

    // Test 2
    printf("Input: %s", test2);
    char *res2 = s21_strcpy(test2new, test2);
    printf("\nOutput: %s", res2);
    s21_strcmp(test2, test2new) == 0 ? printf("\nResult: SUCCESS") : printf("\nResult: FAIL");
    printf("\n\n");

    // Test 3
    printf("Input: %s", test3);
    char *res3 = s21_strcpy(test3new, test3);
    printf("\nOutput: %s", res3);
    s21_strcmp(test3, test3new) == 0 ? printf("\nResult: SUCCESS") : printf("\nResult: FAIL");

    free(test1);
    free(test2);
    free(test3);
    free(test1new);
    free(test2new);
    free(test3new);
}

void s21_strcat_test() {
    char *test1, *test2, *test3, *test4;
    int n1 = 6, n2 = 0, n3 = 1;
    test1 = malloc(n1 * sizeof(char));
    *test1 = 'p', test1[1] = 'r', test1[2] = 'i', test1[3] = 'v', test1[4] = 'e', test1[5] = 't';
    test2 = malloc(n2 * sizeof(char));
    test4 = malloc(n2 * sizeof(char));
    test3 = malloc(n3 * sizeof(char));
    *test3 = 's';

    // Test 1
    printf("Input: %s %s", test1, test3);
    char *res1 = s21_strcat(test1, test3);
    printf("\nOutput: %s\n", res1);
    s21_strlen(res1) == n1 + n3 ? printf("Result: SUCCESS") : printf("Result: FAIL");
    printf("\n\n");

    // Test 2
    printf("Input: %s %s", test2, test4);
    char *res2 = s21_strcat(test2, test4);
    printf("\nOutput: %s\n", res2);
    s21_strlen(res2) == n2 + n2 ? printf("Result: SUCCESS") : printf("Result: FAIL");
    printf("\n\n");

    // Test 3
    printf("Input: %s %s", test3, test1);
    char *res3 = s21_strcat(test3, test1);
    printf("\nOutput: %s\n", res3);
    s21_strlen(res3) == n1 + n3 + n3 ? printf("Result: SUCCESS") : printf("Result: FAIL");

    free(test1);
    free(test2);
    free(test3);
    free(test4);
}

void s21_strchr_test() {
    char *test = "Privet";
    char ch1 = 'P';
    char ch2 = 'p';
    char ch3 = '\0';

    // Test 1
    printf("Input: %s %c", test, ch1);
    char *res1 = s21_strchr(test, ch1);
    printf("\nOutput: %c\n", *res1);
    *res1 == ch1 ? printf("Result: SUCCESS") : printf("Result: FAIL");
    printf("\n\n");

    // Test 2
    printf("Input: %s %c", test, ch2);
    char *res2 = s21_strchr(test, ch2);
    res2 == NULL ? printf("\nOutput: NULL\n") : printf("\nOutput: %c\n", *res2);
    res2 == NULL ? printf("Result: SUCCESS") : printf("Result: FAIL");
    printf("\n\n");

    // Test 3
    printf("Input: %s %c", test, ch3);
    char *res3 = s21_strchr(test, ch3);
    res3 == NULL ? printf("\nOutput: NULL\n") : printf("\nOutput: %c\n", *res3);
    res3 == NULL ? printf("Result: SUCCESS") : printf("Result: FAIL");
}

void s21_strstr_test() {
    char *test = "Hello, world!";
    char *test1 = "world";
    char *test2 = "planet";
    char *test3 = "";

    // Test 1
    printf("Input: %s %s", test, test1);
    char *res1 = s21_strstr(test, test1);
    res1 == NULL ? printf("\nOutput: NULL\n") : printf("\nOutput: %ld\n", res1 - test);
    res1 != NULL ? printf("Result: SUCCESS") : printf("Result: FAIL");
    printf("\n\n");

    // Test 2
    printf("Input: %s %s", test, test2);
    char *res2 = s21_strstr(test, test2);
    res2 == NULL ? printf("\nOutput: NULL\n") : printf("\nOutput: %ld\n", res2 - test);
    res2 == NULL ? printf("Result: SUCCESS") : printf("Result: FAIL");
    printf("\n\n");

    // Test 3
    printf("Input: %s %s", test, test3);
    char *res3 = s21_strstr(test, test3);
    res3 == NULL ? printf("\nOutput: NULL\n") : printf("\nOutput: %ld\n", res3 - test);
    res3 != NULL ? printf("Result: SUCCESS") : printf("Result: FAIL");
}

void s21_strtok_test() {
    char test1[] = "Hello world, this is a test";
    char test2[] = " ";
    char test3[] = "I.AM/A-STRING:LOL;KEK,1.2;3";
    char *sep1 = " ,";
    char *sep2 = ",";
    char *sep3 = "./-:;,";

    // Test 1
    printf("Input string: %s\nSeparators: %c\n", test1, *sep1);
    printf("Output:");
    int k1 = 0;
    char *res1 = s21_strtok(test1, sep1);
    while (res1 != NULL) {
        printf(" %s", res1);
        k1++;
        res1 = s21_strtok(NULL, sep1);
    }
    k1 == 6 ? printf("\nResult: SUCCESS") : printf("\nResult: FAIL");

    // Test 2
    printf("\n\nInput string: %s\nSeparators: %s\n", test2, sep2);
    printf("Output:");
    int k2 = 0;
    char *res2 = s21_strtok(test2, sep2);
    while (res2 != NULL) {
        printf(" %s", res2);
        k2++;
        res2 = s21_strtok(NULL, sep2);
    }
    k2 == 1 ? printf("\nResult: SUCCESS") : printf("\nResult: FAIL");

    // Test 3
    printf("\n\nInput string: %s\nSeparators: %s\n", test3, sep3);
    printf("Output:");
    int k3 = 0;
    char *res3 = s21_strtok(test3, sep3);
    while (res3 != NULL) {
        printf(" %s", res3);
        k3++;
        res3 = s21_strtok(NULL, sep3);
    }
    k3 == 9 ? printf("\nResult: SUCCESS") : printf("\nResult: FAIL");
}

int main() {
#ifdef LEN
    s21_strlen_test();
#endif
#ifdef CMP
    s21_strcmp_test();
#endif
#ifdef CPY
    s21_strcpy_test();
#endif
#ifdef CAT
    s21_strcat_test();
#endif
#ifdef CHR
    s21_strchr_test();
#endif
#ifdef STR
    s21_strstr_test();
#endif
#ifdef TOK
    s21_strtok_test();
#endif
    return 0;
}