#include <stdio.h>

#include "s21_string.h"

#define MAX_TEXT_LENGTH 100

void formatText(int width, char* text) {
    int new = 0;
    int line = 0;
    char* word = s21_strtok(text, " \n");
    while (word != NULL) {
        int word = s21_strlen(word);
        if (line + word + 1 <= width) {
            if (line > 0) {
                putchar(' ');
                line++;
            }
            printf("%s", word);
            line += word;
        } else {
            putchar('\n');
            printf("%s", word);
            line = word;
            new = 1;
        }
        word = s21_strtok(NULL, " \n");
    }
    if (!new) {
        putchar('\n');
    }
}

int main(int argc, char* argv[]) {
    if (argc != 2 || s21_strcmp(argv[1], "-w") != 0) {
        printf("n/a\n");
        return 0;
    }
    int width;
    scanf("%d\n", &width);
    char text[MAX_TEXT_LENGTH];
    fgets(text, MAX_TEXT_LENGTH, stdin);
    formatText(width, text);
    return 0;
}
