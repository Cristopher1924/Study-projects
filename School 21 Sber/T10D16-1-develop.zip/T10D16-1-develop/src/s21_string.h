int s21_strlen(const char *str);
int s21_strcmp(const char *str1, const char *str2);
char *s21_strcpy(char *restrict dest, const char *restrict src);
char *s21_strcat(char *restrict, const char *restrict);
char *s21_strchr(const char *, int);
char *s21_strstr(const char *str1, const char *str2);
char *s21_strtok(char *str, char *sep);