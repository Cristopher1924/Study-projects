#include "s21_string.h"

#include <stdlib.h>

int s21_strlen(const char *str) {
    int length = 0;
    while (*str != '\0') {
        length++;
        str++;
    }
    return length;
}

int s21_strcmp(const char *str1, const char *str2) {
    int cmp = 0;
    while ((*str1 != '\0' || *str2 != '\0') && cmp == 0) {
        if (*str1 < *str2) {
            cmp = -1;
        } else if (*str1 > *str2) {
            cmp = 1;
        }
        str1++, str2++;
    }
    return cmp;
}

char *s21_strcpy(char *restrict dest, const char *restrict src) {
    char *dest_ptr = dest;
    while (*src != '\0') {
        *dest = *src;
        dest++, src++;
    }
    *dest = '\0';
    return dest_ptr;
}

char *s21_strcat(char *restrict dest, const char *restrict src) {
    char *dest_ptr = dest;
    while (*dest != '\0') {
        dest++;
    }
    while (*src != '\0') {
        *dest = *src;
        dest++, src++;
    }
    *dest = '\0';
    return dest_ptr;
}

char *s21_strchr(const char *str, int ch) {
    char *chr = NULL;
    while (*str != '\0' && chr == NULL) {
        if (*str == ch) {
            chr = (char *)str;
        }
        str++;
    }
    return chr;
}

char *s21_strstr(const char *str1, const char *str2) {
    if (!*str2) {
        return (char *)str1;
    }
    char *str = NULL;
    while (*str1 && str == NULL) {
        const char *p1 = str1;
        const char *p2 = str2;
        while (*p1 && *p2 && *p1 == *p2) {
            p1++;
            p2++;
        }
        if (!*p2) {
            str = (char *)str1;
        }
        str1++;
    }
    return str;
}

unsigned int is_delim(char c, char *delim) {
    while (*delim != '\0') {
        if (c == *delim) return 1;
        delim++;
    }
    return 0;
}
char *s21_strtok(char *srcString, char *delim) {
    static char *backup_string;
    if (!srcString) {
        srcString = backup_string;
    }
    if (!srcString) {
        return NULL;
    }
    while (1) {
        if (is_delim(*srcString, delim)) {
            srcString++;
            continue;
        }
        if (*srcString == '\0') {
            return NULL;
        }
        break;
    }
    char *ret = srcString;
    while (1) {
        if (*srcString == '\0') {
            backup_string = srcString;
            return ret;
        }
        if (is_delim(*srcString, delim)) {
            *srcString = '\0';
            backup_string = srcString + 1;
            return ret;
        }
        srcString++;
    }
}