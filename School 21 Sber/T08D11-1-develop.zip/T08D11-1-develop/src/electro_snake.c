#include <stdio.h>
#include <stdlib.h>

void sortVertical(int **matrix, int n, int m, int **result_matrix);
void sortHorizontal(int **matrix, int n, int m, int **result_matrix);

int input(int ***matrix, int *n, int *m);
void output(int **matrix, int n, int m);

int main() {
    int **matrix = NULL;

    int n = 0, m = 0;

    if (input(&matrix, &n, &m)) {
        free(matrix);
        printf("n/a");
        return 0;
    }
    int **res = malloc(n * m * sizeof(int) + n * sizeof(int *));
    int *ptr = (int *)(res + n);
    for (int i = 0; i < n; i++) {
        res[i] = ptr + m * i;
    }

    sortVertical(matrix, n, m, res);
    output(res, n, m);
}

int input(int ***matr, int *n, int *m) {
    int flag = 0;
    double n_d, m_d;
    if (scanf("%lf %lf", &n_d, &m_d) != 2 || (int)n_d != n_d || (int)m_d != m_d || n_d <= 0 || m_d <= 0) {
        flag = 1;
    }
    *n = n_d, *m = m_d;

    if (!flag) {
        *matr = malloc(*n * *m * sizeof(int) + *n * sizeof(int *));
        int *ptr = (int *)(*matr + *n);
        for (int i = 0; i < *n; i++) {
            (*matr)[i] = ptr + *m * i;
        }

        double val_d;
        for (int i = 0; i < *n; i++) {
            for (int j = 0; j < *m; j++) {
                if (scanf("%lf", &val_d) != 1 || (int)val_d != val_d) {
                    flag = 1;
                } else {
                    (*matr)[i][j] = (int)val_d;
                }
            }
        }
    }
    return flag;
}

void output(int **matr, int n, int m) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (j == m - 1) {
                printf("%d", matr[i][j]);
            } else {
                printf("%d ", matr[i][j]);
            }
        }
        if (i != n - 1) {
            printf("\n");
        }
    }
}

void sortVertical(int **matr, int n, int m, int **res) {
    int k = 0;
    for (int j = 0; j < m; j++) {
        if (j % 2 == 0) {
            for (int i = 0; i < n; i++) {
                res[i][j] = matr[k][j];
                k++;
            }
        } else {
            for (int i = n - 1; i >= 0; i--) {
                res[i][j] = matr[k][j];
                k++;
            }
        }
    }
}