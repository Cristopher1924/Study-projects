#include <stdio.h>
#include <stdlib.h>

int input(double ***matr, int *n, int *m);
double det(double **matrix, int n);
void output(double res);
void freeData(double **matr, int n);
void outputMatrix(double **matr, int n);
void matrixWithoutRowAndColumn(double **matr, int n, int row, int col, double **newmatr);

int main() {
    int n = 0, m = 0;
    double **matr = NULL;

    if (input(&matr, &n, &m) || n != m) {
        printf("n/a");
        freeData(matr, n);
        return 1;
    }

    // outputMatrix(matr, n);

    double res = det(matr, n);
    output(res);
    freeData(matr, n);
    return 0;
}

void outputMatrix(double **matr, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (j == n - 1) {
                printf("%lf", matr[i][j]);
            } else {
                printf("%lf ", matr[i][j]);
            }
        }
        if (i != n - 1) {
            printf("\n");
        }
    }
}

void output(double res) { printf("%lf", res); }

int input(double ***matr, int *n, int *m) {
    int flag = 0;

    // Reading n and m
    double n_d, m_d;
    if (scanf("%lf %lf", &n_d, &m_d) != 2 || (int)n_d != n_d || (int)m_d != m_d || (int)n_d <= 0 ||
        (int)m_d <= 0) {
        flag = 1;
    }
    *n = (int)n_d, *m = (int)m_d;

    // Allocating the data for the matrix
    if (!flag) {
        *matr = (double **)malloc(*n * sizeof(double *));
        for (int i = 0; i < *n; ++i) {
            (*matr)[i] = (double *)malloc(*m * sizeof(double));
        }

        double val_d;
        for (int i = 0; i < *n; ++i) {
            for (int j = 0; j < *m; ++j) {
                if (scanf("%lf", &val_d) != 1) {
                    flag = 1;
                } else {
                    (*matr)[i][j] = val_d;
                }
            }
        }
    }

    return flag;
}

void freeData(double **matr, int n) {
    for (int i = 0; i < n; i++) {
        free(matr[i]);
    }
    free(matr);
}

void matrixWithoutRowAndColumn(double **matr, int n, int row, int col, double **newmatr) {
    int offsetRow = 0, offsetCol = 0;
    for (int i = 0; i < n - 1; i++) {
        if (i == row) {
            offsetRow = 1;
        }
        offsetCol = 0;
        for (int j = 0; j < n - 1; j++) {
            if (j == col) {
                offsetCol = 1;
            }
            newmatr[i][j] = matr[i + offsetRow][j + offsetCol];
        }
    }
}

double det(double **matr, int size) {
    double res = 0;
    int degree = 1;
    if (size == 1) {
        return matr[0][0];
    } else if (size == 2) {
        return matr[0][0] * matr[1][1] - matr[0][1] * matr[1][0];
    }

    double **newmatr = (double **)malloc((size - 1) * sizeof(double *));
    for (int i = 0; i < size - 1; i++) {
        newmatr[i] = (double *)malloc((size - 1) * sizeof(double));
    }

    for (int j = 0; j < size; j++) {
        matrixWithoutRowAndColumn(matr, size, 0, j, newmatr);
        res = res + (degree * matr[0][j] * det(newmatr, size - 1));
        degree = -degree;
    }
    freeData(newmatr, size - 1);
    return res;
}