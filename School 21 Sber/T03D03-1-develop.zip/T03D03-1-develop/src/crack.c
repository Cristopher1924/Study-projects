#include <stdio.h>

int main() {
    double x, y;
    if (!scanf("%lf %lf", &x, &y)) {
        printf("n/a");
        return 0;
    }
    if (x * x + y * y <= 25) {
        printf("GOTCHA");
    } else {
        printf("MISS");
    }
}