#include <stdio.h>

void sum(int a, int b) { printf("%d", a + b); }

void sub(int a, int b) { printf("%d", a - b); }

void multi(int a, int b) { printf("%d", a * b); }

void divis(int a, int b) {
    if (b == 0) {
        printf("n/a");
    } else {
        printf("%d", a / b);
    }
}

int main() {
    double a = 0, b = 0;
    if (!scanf("%lf %lf", &a, &b)) {
        printf("n/a");
        return 0;
    }
    if (a != (int)a || b != (int)b) {
        printf("n/a");
        return 0;
    }
    sum((int)a, (int)b);
    printf(" ");
    sub((int)a, (int)b);
    printf(" ");
    multi((int)a, (int)b);
    printf(" ");
    divis((int)a, (int)b);
}