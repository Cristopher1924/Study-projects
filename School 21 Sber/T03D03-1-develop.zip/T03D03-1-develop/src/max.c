#include <stdio.h>

int max(int a, int b) {
    if (a >= b) {
        return a;
    } else {
        return b;
    }
}

int main() {
    double a, b;
    if (!scanf("%lf %lf", &a, &b)) {
        printf("n/a");
        return 0;
    }
    if (a != (int)a || b != (int)b) {
        printf("n/a");
        return 0;
    }
    printf("%d", max((int)a, (int)b));
}