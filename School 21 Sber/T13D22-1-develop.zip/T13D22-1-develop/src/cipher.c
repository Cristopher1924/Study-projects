#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef LOG
#include "log_levels.h"
#include "logger.h"
#endif

#ifdef DES
#include <openssl/des.h>

void encryptFiles(char *directory);
#endif

#define MAXN 1024

void getMode(int *mode);
void displayFileContent(char *filename);
void appendToFile(char *filename, char *str);
void printFile(FILE *file);
void processFilesInDirectory(char *path, int shift);
void caesarCipher(FILE *file, int shift);

int main() {
    int mode;
    int flag = 0;
    getMode(&mode);
    char filename[MAXN];
    char str[MAXN];
    char path[MAXN];
    int havefilename = 0;
#ifdef LOG
    FILE *log = log_init("logs.txt");
#endif
    while (flag == 0 && mode != -1) {
        if (mode == 1) {
            if (scanf("%s", filename) != 1) {
                flag++;
                havefilename = 0;
            } else {
                havefilename = 1;
                displayFileContent(filename);
#ifdef LOG
                logcat(log, "File opened.", info);
#endif
            }

        } else if (mode == 2) {
            getchar();
            fgets(str, sizeof(str), stdin);
            if (strlen(str) > 0 && str[strlen(str) - 1] == '\n') {
                str[strlen(str) - 1] = '\0';
            }
            if (havefilename) {
                appendToFile(filename, str);
#ifdef LOG
                logcat(log, "The file was changed", info);
#endif
            } else {
                flag++;
#ifdef LOG
                logcat(log, "The file name wasn't entered.", error);
#endif
            }
        } else if (mode == 3) {
            double shift_d;
            if (scanf("%s\n%lf", path, &shift_d) != 2 || shift_d != (int)shift_d) {
                flag++;
            } else {
                processFilesInDirectory(path, (int)shift_d);
#ifdef LOG
                logcat(log, "The file was encrypted.", info);
#endif
            }
        }
#ifdef DES
        else if (mode == 4) {
            if (scanf("%s", path) != 1) {
                flag++;
            } else {
                encryptFiles(path);
            }
        }
#endif
        else {
            printf("n/a\n");
            while (getchar() != '\n') {
                continue;
            }
        }
        getMode(&mode);
    }

    if (flag) {
#ifdef LOG
        logcat(log, "Incorrect value entered.", error);
#endif
        printf("n/a");
    }
#ifdef LOG
    log_close(log);
#endif
}

void getMode(int *mode) {
    double mode_d;
    if (scanf("%lf", &mode_d) != 1 || mode_d != (int)mode_d) {
        *mode = 0;
    } else {
        *mode = (int)mode_d;
    }
}

void displayFileContent(char *filename) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("n/a\n");
    } else {
        printFile(file);
        printf("\n");
        fclose(file);
    }
}

void appendToFile(char *filename, char *str) {
    FILE *file = fopen(filename, "r");
    if (file == NULL) {
        printf("n/a\n");
    } else {
        fclose(file);
        FILE *file = fopen(filename, "a");
        fprintf(file, "%s", str);
        fclose(file);
        displayFileContent(filename);
    }
}

void printFile(FILE *file) {
    char ch;
    int flag = 0;
    while ((ch = fgetc(file)) != EOF) {
        putchar(ch);
        flag++;
    }
    if (!flag) {
        printf("n/a");
    }
}

void processFilesInDirectory(char *path, int shift) {
    DIR *dir = opendir(path);
    if (dir == NULL) {
        printf("n/a\n");
    } else {
        struct dirent *entry;
        while ((entry = readdir(dir)) != NULL) {
            char filename[MAXN];
            strcpy(filename, path);
            strcat(filename, "/");
            strcat(filename, entry->d_name);

            if (filename[strlen(filename) - 1] == 'c' && filename[strlen(filename) - 2] == '.') {
                FILE *file = fopen(filename, "r+");
                caesarCipher(file, shift);
                fclose(file);
            } else if (filename[strlen(filename) - 1] == 'h' && filename[strlen(filename) - 2] == '.') {
                FILE *file = fopen(filename, "w");
                fclose(file);
            }
        }
        closedir(dir);
    }
}

void caesarCipher(FILE *file, int shift) {
    char ch;
    while ((ch = fgetc(file)) != EOF) {
        if (ch >= 'a' && ch <= 'z') {
            ch = 'a' + (ch - 'a' + shift) % 26;
        } else if (ch >= 'A' && ch <= 'Z') {
            ch = 'A' + (ch - 'A' + shift) % 26;
        }
        fseek(file, -1, SEEK_CUR);
        fputc(ch, file);
    }
}
#ifdef DES
void encryptFiles(char *directory) {
    DIR *dir = opendir(directory);
    if (dir == NULL) {
        printf("n/a\n");
        return;
    } else {
        struct dirent *entry;
        while ((entry = readdir(dir)) != NULL) {
            char *filename = entry->d_name;
            if (filename[strlen(filename) - 1] == 'c' && filename[strlen(filename) - 2] == '.') {
                // Encrypt .c file using DES

                // Create input and output file paths
                char inputPath[256];
                char outputPath[256];
                sprintf(inputPath, "%s/%s", directory, filename);
                sprintf(outputPath, "%s/%s.enc", directory, filename);

                // Open input and output files
                FILE *inputFile = fopen(inputPath, "rb");
                FILE *outputFile = fopen(outputPath, "wb");

                if (inputFile == NULL || outputFile == NULL) {
                    printf("Error opening file: %s", filename);
                    continue;
                }

                // Set up DES encryption
                DES_cblock key;
                DES_random_key(&key);
                DES_key_schedule schedule;
                DES_set_key_checked(&key, &schedule);

                // Encrypt using DES in chunks
                unsigned char input[8];
                unsigned char output[8];
                size_t bytesRead;

                while ((bytesRead = fread(input, 1, 8, inputFile)) > 0) {
                    if (bytesRead < 8) {
                        memset(input + bytesRead, 0, 8 - bytesRead);
                        DES_ecb_encrypt((DES_cblock *)input, (DES_cblock *)output, &schedule, DES_ENCRYPT);
                    } else {
                        DES_ecb_encrypt((DES_cblock *)input, (DES_cblock *)output, &schedule, DES_ENCRYPT);
                    }

                    fwrite(output, 1, 8, outputFile);
                }

                fclose(inputFile);
                fclose(outputFile);
                remove(inputPath);
            } else if (filename[strlen(filename) - 1] == 'h' && filename[strlen(filename) - 2] == '.') {
                char filePath[256];
                sprintf(filePath, "%s/%s", directory, filename);
                FILE *file = fopen(filePath, "w");
                if (file == NULL) {
                    printf("n/a\n");
                    continue;
                }
                fclose(file);
            }
        }
    }

    closedir(dir);
}
#endif