#include "logger.h"

#include <stdio.h>
#include <time.h>

#include "log_levels.h"

FILE* log_init(char* filename) {
    FILE* log_file = fopen(filename, "a");
    return log_file;
}

int logcat(FILE* log_file, char* message, enum log_level level) {
    if (log_file == NULL) {
        return -1;
    }

    char* level_strings[] = {"DEBUG", "TRACE", "INFO", "WARNING", "ERROR"};
    time_t raw_time;
    struct tm* time_info;
    time(&raw_time);
    time_info = localtime(&raw_time);
    char time_str[20];
    strftime(time_str, sizeof(time_str), "%Y-%m-%d %H:%M:%S", time_info);

    fprintf(log_file, "[%s] %s - %s\n", level_strings[level], time_str, message);
    fflush(log_file);
    return 0;
}

int log_close(FILE* log_file) {
    if (log_file != NULL) {
        fclose(log_file);
        return 0;
    }
    return -1;
}