#include <stdio.h>
#include <stdlib.h>

#include "../data_libs/data_io.h"
#include "../data_libs/data_stat.h"
#include "../yet_another_decision_module/decision.h"

#ifdef DYNAMIC_BUILD
#include <dlfcn.h>
#else
#include "../data_module/data_process.h"
#endif

void sort(double *data, int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (data[j] > data[j + 1]) {
                double buf = data[j];
                data[j] = data[j + 1];
                data[j + 1] = buf;
            }
        }
    }
}

int main() {
    double *data;
    double n_d;
    int n;

#ifdef DYNAMIC_BUILD
    void *ext_library;
    double (*func)(double *data, int n);
    ext_library = dlopen("libdata_process.so", RTLD_LAZY);
    func = dlsym(ext_library, "normalization");
#endif

    printf("LOAD DATA...\n");

    if (scanf("%lf", &n_d) != 1 || (int)n_d != n_d) {
        printf("n/a");
        return 0;
    }
    n = (int)n_d;
    data = malloc(n * sizeof(double));
    input(data, n);

    printf("RAW DATA:\n\t");
    output(data, n);

    printf("\nNORMALIZED DATA:\n\t");

#ifdef DYNAMIC_BUILD
    (*func)(data, n);
#else
    normalization(data, n);
#endif

    output(data, n);

    printf("\nSORTED NORMALIZED DATA:\n\t");
    sort(data, n);
    output(data, n);

    printf("\nFINAL DECISION:\n\t");
    if (make_decision(data, n))
        printf("YES");
    else
        printf("NO");

    free(data);
    return 0;
}
