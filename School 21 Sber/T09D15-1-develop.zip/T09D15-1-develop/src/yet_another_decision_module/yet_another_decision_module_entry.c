#include <stdio.h>
#include <stdlib.h>

#include "../data_libs/data_io.h"
#include "decision.h"

int main() {
    double *data;
    double n_d;
    int n;

    if (scanf("%lf", &n_d) != 1 || (int)n_d != n_d) {
        printf("n/a");
        return 0;
    }
    n = (int)n_d;

    data = malloc(n * sizeof(double));

    input(data, n);

    if (make_decision(data, n))
        printf("YES");
    else
        printf("NO");

    free(data);

    return 0;
}
