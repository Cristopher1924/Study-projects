#include "data_stat.h"

double max(double *data, int n) {
    double max_value = data[0];
    for (int i = 1; i < n; i++) {
        max_value = max_value < data[i] ? data[i] : max_value;
    }
    return max_value;
}

double min(double *data, int n) {
    double min_value = data[0];
    for (int i = 1; i < n; i++) {
        min_value = min_value > data[i] ? data[i] : min_value;
    }
    return min_value;
}

double mean(double *data, int n) {
    double res = 0.0;
    for (int i = 0; i < n; i++) {
        res += data[i];
    }
    return res / n;
}

double variance(double *data, int n) {
    double mean_current = mean(data, n);
    double res = 0.0;
    for (int i = 0; i < n; i++) {
        res += (data[i] - mean_current) * (data[i] - mean_current);
    }
    return res / n;
}